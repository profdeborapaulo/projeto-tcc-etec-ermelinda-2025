<?php
/* config/conexao.php */
$host = '212.85.3.45';
$user ='u879079983_sageuser';
$pass = 'Sage_2025';
$db   = 'u879079983_sageadata';

$conexao = new mysqli($host, $user, $pass, $db);

if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}
$conexao->set_charset("utf8mb4");
?>