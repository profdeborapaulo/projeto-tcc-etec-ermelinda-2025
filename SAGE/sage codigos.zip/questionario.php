<?php
session_start();
require_once 'config/conexao.php';

// 1. Segurança: Verifica login e se já fez a inscrição básica
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if (!isset($_SESSION['id_inscricao'])) {
    // Tenta recuperar o ID da inscrição se não estiver na sessão
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT id FROM inscricoes WHERE usuario_id = '$user_id' ORDER BY id DESC LIMIT 1";
    $res = $conexao->query($sql);
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $_SESSION['id_inscricao'] = $row['id'];
    } else {
        header("Location: inscricao.php");
        exit;
    }
}

$msg_erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inscricao_id = $_SESSION['id_inscricao'];
    
    // Coleta as respostas
    $q1 = $_POST['problemaCoracao'];
    $q2 = $_POST['dorPeitoAtividade'];
    $q3 = $_POST['dorPeitoUltimoMes'];
    $q4 = $_POST['tonturaPerdaConsciencia'];
    $q5 = $_POST['problemaOsseoArticular'];
    $q6 = $_POST['medicamentoPressao'];
    $q7 = $_POST['outraRazao'];

    // Insere no banco
    $sql = "INSERT INTO questionario_saude (
                inscricao_id, q1_coracao, q2_dor_peito, q3_dor_ultimo_mes, 
                q4_tontura, q5_osseo, q6_medicamento, q7_outra_razao
            ) VALUES (
                '$inscricao_id', '$q1', '$q2', '$q3', '$q4', '$q5', '$q6', '$q7'
            )";

    if ($conexao->query($sql) === TRUE) {
        // Redireciona para a carteirinha final
        header("Location: carteirinha.php");
        exit;
    } else {
        $msg_erro = "Erro ao salvar respostas: " . $conexao->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAGE - Questionário PAR-Q</title>
    <link rel="icon" href="assets/img/Logo.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/questionario.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="questionario-container">
        <div class="header">
            <div class="header-content">
                <div class="icon-container">
                    <div class="icon"><i class="fas fa-heartbeat"></i></div>
                </div>
                <h1>Questionário de Saúde (PAR-Q)</h1>
                <p class="subtitle">Responda honestamente para garantir sua segurança</p>
            </div>
        </div>

        <?php if($msg_erro): ?>
            <div style="background:#f8d7da; color:#721c24; padding:15px; text-align:center;"><?php echo $msg_erro; ?></div>
        <?php endif; ?>

        <form class="questionario-form" method="POST" action="questionario.php">
            <div class="form-section">
                <div class="question-group">
                    
                    <div class="question">
                        <p class="question-text"><strong>1.</strong> Algum médico já disse que você possui algum problema de coração?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="problemaCoracao" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="problemaCoracao" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                    <div class="question">
                        <p class="question-text"><strong>2.</strong> Você sente dores no peito quando pratica atividade física?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="dorPeitoAtividade" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="dorPeitoAtividade" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                    <div class="question">
                        <p class="question-text"><strong>3.</strong> No último mês, você sentiu dores no peito quando praticou atividade física?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="dorPeitoUltimoMes" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="dorPeitoUltimoMes" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                    <div class="question">
                        <p class="question-text"><strong>4.</strong> Você apresenta desequilíbrio devido a tontura e/ou perda de consciência?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="tonturaPerdaConsciencia" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="tonturaPerdaConsciencia" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                    <div class="question">
                        <p class="question-text"><strong>5.</strong> Você possui algum problema ósseo ou articular?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="problemaOsseoArticular" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="problemaOsseoArticular" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                    <div class="question">
                        <p class="question-text"><strong>6.</strong> Você toma atualmente algum medicamento para pressão arterial ou coração?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="medicamentoPressao" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="medicamentoPressao" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                    <div class="question">
                        <p class="question-text"><strong>7.</strong> Sabe de alguma outra razão pela qual você não deve praticar atividade física?</p>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="outraRazao" value="sim" required>
                                <span class="radio-custom"></span><span class="option-text">Sim</span>
                            </label>
                            <label class="option">
                                <input type="radio" name="outraRazao" value="nao" required>
                                <span class="radio-custom"></span><span class="option-text">Não</span>
                            </label>
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">FINALIZAR E GERAR CARTEIRINHA</button>
            </div>
        </form>
    </div>
</body>
</html>