<?php
// login.php
session_start();
require_once 'config/conexao.php';

$msg_erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conexao->real_escape_string($_POST['email']);
    $senha = $_POST['senha'];

    $sql = "SELECT id, nome, senha, is_admin FROM usuarios WHERE email = '$email'";
    $result = $conexao->query($sql);

    if ($result->num_rows == 1) {
        $usuario = $result->fetch_assoc();
        if ($senha === $usuario['senha']) { // Em produção use password_verify()
            $_SESSION['user_id'] = $usuario['id'];
            $_SESSION['user_nome'] = $usuario['nome'];
            
            // REDIRECIONA PARA O INDEX (que fará o roteamento inteligente)
            header("Location: index.php");
            exit;
        } else {
            $msg_erro = "Senha incorreta.";
        }
    } else {
        $msg_erro = "Usuário não encontrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAGE - Login</title>
    <link rel="stylesheet" href="assets/css/login.css">
    <link rel="icon" href="assets/img/Logo.png" type="image/x-icon">
    <style>.alert-danger { background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 8px; text-align: center; margin-bottom: 15px; }</style>
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <img src="assets/img/LogoAzul.jpeg" alt="SAGE Logo" class="login-logo">
        </div>
        <div class="login-header">
            <h1>Bem-vindo ao SAGE!</h1>
            <p class="welcome-text">Sistema Automatizado de Gestão Esportiva</p>
            <div class="divider"></div>
        </div>
        <?php if(!empty($msg_erro)): ?>
            <div class="alert-danger"><?php echo $msg_erro; ?></div>
        <?php endif; ?>
        <form class="login-form" id="loginForm" action="login.php" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="seu@email.com" required>
            </div>
            <div class="form-group">
                <label for="password">Senha</label>
                <div class="password-input-container">
                    <input type="password" id="password" name="senha" class="form-control" placeholder="Sua senha" required>
                </div>
            </div>
            <button type="submit" class="login-btn">ENTRAR</button>
        </form>
        <div class="login-footer">
            <p>Não tem uma conta? <a href="cadastro.php" class="link">Cadastre-se</a></p>
        </div>
    </div>
</body>
</html>