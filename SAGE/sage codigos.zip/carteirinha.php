<?php
// carteirinha.php - VERSÃO FINAL ESTÁVEL (QR Code = ID do Aluno)
session_start();

// Configurações de erro (remova em produção)
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/conexao.php';

// 1. Segurança
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$mensagem_erro = "";

// 2. Upload de Foto
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['foto_perfil'])) {
    $arquivo = $_FILES['foto_perfil'];
    if ($arquivo['error'] === UPLOAD_ERR_OK) {
        $pasta_destino = __DIR__ . '/assets/uploads/';
        $caminho_relativo = 'assets/uploads/';
        
        if (!is_dir($pasta_destino)) { mkdir($pasta_destino, 0777, true); }
        
        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        if (in_array($extensao, ['jpg', 'jpeg', 'png'])) {
            $nome_arquivo = $user_id . "_" . time() . "." . $extensao;
            if (move_uploaded_file($arquivo['tmp_name'], $pasta_destino . $nome_arquivo)) {
                $caminho_banco = $caminho_relativo . $nome_arquivo;
                $stmt = $conexao->prepare("UPDATE inscricoes SET foto_caminho = ? WHERE usuario_id = ?");
                $stmt->bind_param("si", $caminho_banco, $user_id);
                $stmt->execute();
                header("Location: carteirinha.php");
                exit;
            } else {
                $mensagem_erro = "Erro ao salvar arquivo.";
            }
        } else {
            $mensagem_erro = "Formato inválido.";
        }
    }
}

// 3. Busca Dados
$sql = "SELECT * FROM inscricoes WHERE usuario_id = '$user_id' ORDER BY id DESC LIMIT 1";
$result = $conexao->query($sql);

if ($result->num_rows > 0) {
    $dados = $result->fetch_assoc();
    
    $nome = $dados['nome_completo'];
    $modalidade = $dados['modalidade'];
    $horario = $dados['horario'];
    $nascimento = date('d/m/Y', strtotime($dados['data_nascimento']));
    $status = $dados['status_inscricao'];
    
    // ID Formatado (Ex: 00005) - ESTE SERÁ O CONTEÚDO DO QR CODE
    $id_formatado = str_pad($dados['id'], 5, '0', STR_PAD_LEFT);
    
    // Frequência
    $aluno_id = $dados['id'];
    $sql_freq = "SELECT COUNT(*) as total FROM frequencia WHERE aluno_id = '$aluno_id' AND presenca = 'presente'";
    $res_freq = $conexao->query($sql_freq);
    $frequencia = $res_freq->fetch_assoc()['total'];
    
    // Foto
    $caminho_fisico = __DIR__ . '/' . $dados['foto_caminho'];
    $tem_foto = !empty($dados['foto_caminho']) && file_exists($caminho_fisico);
    $foto_url = $tem_foto ? $dados['foto_caminho'] . "?t=" . time() : 'assets/img/user-placeholder.jpg';
    
    // Cores Status
    switch($status) {
        case 'ativo':
            $status_cor = '#10b981'; $status_icone = 'fa-check-circle'; $status_texto = 'ATIVO'; break;
        case 'rejeitado':
            $status_cor = '#ef4444'; $status_icone = 'fa-times-circle'; $status_texto = 'RECUSADO'; break;
        default:
            $status_cor = '#f59e0b'; $status_icone = 'fa-clock'; $status_texto = 'PENDENTE';
    }

} else {
    header("Location: inscricao.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Carteirinha Digital - SAGE</title>
  <link rel="icon" href="assets/img/Logo.png" type="image/x-icon">
  <link rel="stylesheet" href="assets/css/carteirinha.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

  <style>
    .foto-wrapper.com-foto .foto-overlay { opacity: 0; }
    .foto-wrapper.com-foto:hover .foto-overlay { opacity: 1; }
    .status-badge { background-color: <?php echo $status_cor; ?> !important; color: white; }
    .freq-badge {
        background: #f8fafc; border-left: 4px solid #10b981; padding: 10px 15px;
        border-radius: 8px; margin-top: 15px; display: flex; justify-content: space-between;
        align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    /* Estilo do Box do QR Code */
    .qr-code-box {
        width: 160px; height: 160px; background: white; 
        border-radius: 14px; display: flex; align-items: center; 
        justify-content: center; border: 3px solid #e3a627; 
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        overflow: hidden;
        padding: 10px; /* Espaço interno seguro */
    }
    /* Garante que o QR code gerado não estoure o tamanho */
    .qr-code-box img {
        width: 100%;
        height: auto;
    }
  </style>
</head>
<body>

  <?php if(!empty($mensagem_erro)): ?>
    <div style="position:fixed; top:0; left:0; width:100%; background:#f8d7da; color:#721c24; text-align:center; padding:15px; z-index:9999;">
        <i class="fas fa-exclamation-triangle"></i> <?php echo $mensagem_erro; ?>
    </div>
  <?php endif; ?>

  <div class="floating-actions">
    <button class="btn-floating primary" onclick="window.print()" title="Imprimir"><i class="fas fa-print"></i></button>
    <a href="logout.php" class="btn-floating secondary" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
  </div>

  <div class="carteirinha-container">
    <div class="carteirinha-card">
      
      <div class="carteirinha-header">
        <div class="logo-centralizada">
          <img src="assets/img/Logo.png" alt="SAGE" class="logo-sage">
          <div class="header-text"><h1 class="titulo">SAGE</h1><p class="subtitulo">Gestão Esportiva Municipal</p></div>
        </div>
        <div class="header-badge">
          <h2 class="titulo-carteirinha">ALUNO</h2>
          <div class="status-badge"><i class="fas <?php echo $status_icone; ?>"></i> <span><?php echo $status_texto; ?></span></div>
        </div>
      </div>

      <div class="carteirinha-content">
        
        <div class="foto-section">
            <?php if (!$tem_foto): ?>
                <form id="formFoto" method="POST" enctype="multipart/form-data">
                    <div class="foto-wrapper" onclick="document.getElementById('inputFoto').click()" style="cursor: pointer;">
                        <img src="<?php echo $foto_url; ?>" class="foto-aluno">
                        <input type="file" name="foto_perfil" id="inputFoto" style="display:none" accept="image/*" onchange="document.getElementById('formFoto').submit()">
                        <div class="foto-overlay"><i class="fas fa-camera"></i><span>Adicionar</span></div>
                    </div>
                </form>
                <span class="foto-label">ADICIONAR FOTO</span>
            <?php else: ?>
                <div class="foto-wrapper com-foto" onclick="document.getElementById('inputFotoTroca').click()" style="cursor: pointer;">
                    <img src="<?php echo $foto_url; ?>" class="foto-aluno">
                    <form id="formFotoTroca" method="POST" enctype="multipart/form-data" style="display:none;">
                        <input type="file" name="foto_perfil" id="inputFotoTroca" accept="image/*" onchange="document.getElementById('formFotoTroca').submit()">
                    </form>
                    <div class="foto-overlay"><i class="fas fa-edit"></i><span>Alterar</span></div>
                </div>
                <span class="foto-label" style="color: #10b981;">FOTO REGISTRADA</span>
            <?php endif; ?>
        </div>

        <div class="dados-section">
          <div class="section-title"><i class="fas fa-user-graduate"></i><h3>Dados Pessoais</h3></div>
          <div class="input-group">
            <label>Nome Completo</label>
            <div class="input-field-wrapper"><input type="text" class="input-field" value="<?php echo $nome; ?>" readonly><i class="fas fa-user input-icon"></i></div>
          </div>
          <div class="input-row">
            <div class="input-group">
                <label>Matrícula (ID)</label>
                <div class="input-field-wrapper"><input type="text" class="input-field" value="<?php echo $id_formatado; ?>" readonly><i class="fas fa-id-card input-icon"></i></div>
            </div>
            <div class="input-group">
                <label>Nascimento</label>
                <div class="input-field-wrapper"><input type="text" class="input-field" value="<?php echo $nascimento; ?>" readonly><i class="fas fa-calendar input-icon"></i></div>
            </div>
          </div>

          <div class="section-title"><i class="fas fa-dumbbell"></i><h3>Atividade & Frequência</h3></div>
          <div class="input-row">
            <div class="input-group">
                <label>Modalidade</label>
                <div class="input-field-wrapper"><input type="text" class="input-field" value="<?php echo ucfirst($modalidade); ?>" readonly><i class="fas fa-running input-icon"></i></div>
            </div>
            <div class="input-group">
                <label>Horário</label>
                <div class="input-field-wrapper"><input type="text" class="input-field" value="<?php echo ucfirst($horario); ?>" readonly><i class="fas fa-clock input-icon"></i></div>
            </div>
          </div>

          <div class="freq-badge">
              <div>
                  <span style="color:#64748b; font-size:0.85rem; font-weight:600;">Frequência Total</span>
                  <div style="font-size:1.2rem; font-weight:bold; color:#020D30;"><?php echo $frequencia; ?> <span style="font-size:0.9rem; font-weight:normal;">aulas</span></div>
              </div>
              <i class="fas fa-chart-line" style="font-size:1.5rem; color:#10b981;"></i>
          </div>
        </div>

        <div class="qr-section">
          <div class="qr-container">
            <div id="qrcode" class="qr-code-box"></div>
          </div>
          <p class="qr-label">CÓDIGO DE ACESSO</p>
          <p style="font-size: 0.8rem; color: #b8c2d4; margin-top: 5px;"><?php echo $id_formatado; ?></p>
        </div>

      </div>
      <div class="carteirinha-footer">
        <div class="footer-info"><p>Uso pessoal e intransferível • SAGE 2025</p></div>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    // Definimos o conteúdo do QR Code como o ID do Aluno (Matrícula)
    var conteudoQR = "<?php echo $id_formatado; ?>";
    
    // Gera o QR Code
    try {
        // Limpa qualquer conteúdo anterior
        document.getElementById("qrcode").innerHTML = "";
        
        new QRCode(document.getElementById("qrcode"), {
            text: conteudoQR,
            width: 130,  // Tamanho ajustado para caber na caixa
            height: 130,
            colorDark : "#020D30", // Azul escuro
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
        });
        console.log("QR Code gerado para ID: " + conteudoQR);
    } catch (e) {
        console.error("Erro ao gerar QR Code:", e);
        document.getElementById("qrcode").innerHTML = "<span style='font-size:12px; color:red'>Erro ao carregar</span>";
    }
  </script>

</body>
</html>