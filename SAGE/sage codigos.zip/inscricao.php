<?php
// inscricao.php - COM TERMO DE RESPONSABILIDADE (MODAL)
session_start();
require_once 'config/conexao.php';

// Verifica Login
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$user_id = $_SESSION['user_id'];

// Busca modalidades do banco
$esportes_query = $conexao->query("SELECT nome FROM esportes");
$user_data = $conexao->query("SELECT nome, email FROM usuarios WHERE id = '$user_id'")->fetch_assoc();

// Processamento do Formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Upload PDF
    $atestado_path = null;
    if (isset($_FILES['atestadoMedico']) && $_FILES['atestadoMedico']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['atestadoMedico']['name'], PATHINFO_EXTENSION));
        if ($ext == 'pdf') {
            $dir = 'assets/docs/';
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            $novo_nome = "atestado_" . $user_id . "_" . time() . ".pdf";
            if(move_uploaded_file($_FILES['atestadoMedico']['tmp_name'], $dir . $novo_nome)){
                $atestado_path = $dir . $novo_nome;
            }
        }
    }

    // Dados
    $nome = $conexao->real_escape_string($_POST['nomeCompleto']);
    $nasc = $_POST['dataNascimento'];
    $cpf = $conexao->real_escape_string($_POST['cpf']);
    $rg = $conexao->real_escape_string($_POST['rg']);
    $tel = $conexao->real_escape_string($_POST['telefone']);
    $email = $conexao->real_escape_string($_POST['email']);
    
    // Endereço Formatado
    $rua = $_POST['endereco'];
    $num = $_POST['numero'];
    $bairro = $_POST['bairro'];
    $end_completo = "$rua, $num - $bairro"; 
    
    $cid = $conexao->real_escape_string($_POST['cidade']);
    $est = $conexao->real_escape_string($_POST['estado']);
    $mod = $conexao->real_escape_string($_POST['modalidade']);
    $hor = $conexao->real_escape_string($_POST['horario']);
    $cont = $conexao->real_escape_string($_POST['contatoEmergencia']);
    $tel_em = $conexao->real_escape_string($_POST['telefoneEmergencia']);
    $par = $conexao->real_escape_string($_POST['parentesco']);
    $termos = 1; // Confirmado pelo checkbox

    $sql = "INSERT INTO inscricoes (usuario_id, nome_completo, data_nascimento, cpf, rg, telefone, email, endereco, cidade, estado, modalidade, horario, contato_emergencia, telefone_emergencia, parentesco, termos_aceitos, atestado_medico, status_inscricao) 
            VALUES ('$user_id', '$nome', '$nasc', '$cpf', '$rg', '$tel', '$email', '$end_completo', '$cid', '$est', '$mod', '$hor', '$cont', '$tel_em', '$par', '$termos', '$atestado_path', 'pendente')";

    if ($conexao->query($sql)) {
        $_SESSION['id_inscricao'] = $conexao->insert_id;
        header("Location: questionario.php");
        exit;
    } else {
        $msg_erro = "Erro ao salvar: " . $conexao->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAGE - Inscrição</title>
    <link rel="icon" href="assets/img/Logo.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/inscricao.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .modal-termo-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(5px);
        }
        .modal-termo-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 700px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            position: relative;
        }
        .termo-text {
            font-size: 0.95rem;
            color: #475569;
            line-height: 1.6;
            text-align: justify;
            margin-bottom: 15px;
            padding: 15px;
            background: #f8fafc;
            border-left: 4px solid #e3a627;
            border-radius: 4px;
        }
        .modal-close-btn {
            position: absolute;
            top: 15px;
            right: 20px;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: #64748b;
            cursor: pointer;
        }
    </style>
    <script src="assets/js/inscricao.js" defer></script> 
</head>
<body>
    <div class="inscricao-container">
        
        <div class="header">
            <div class="header-content">
                <div class="icon-container"><div class="icon"><i class="fas fa-file-signature"></i></div></div>
                <h1>INSCRIÇÃO</h1>
                <p class="subtitle">Preenchimento Automático e Seguro</p>
            </div>
        </div>

        <?php if(isset($msg_erro)): ?>
            <div style="background:#f8d7da; color:#721c24; padding:15px; margin:20px; border-radius:8px; text-align:center;">
                <?php echo $msg_erro; ?>
            </div>
        <?php endif; ?>

        <form class="inscricao-form" method="POST" enctype="multipart/form-data" id="formInscricao">
            
            <div class="form-section">
                <h2 class="section-title">Dados Pessoais</h2>
                <div class="form-group">
                    <label class="required">Nome Completo</label>
                    <input type="text" name="nomeCompleto" class="form-control" value="<?php echo $user_data['nome']; ?>" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="required">Nascimento</label>
                        <input type="date" name="dataNascimento" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="required">CPF</label>
                        <input type="text" name="cpf" class="form-control" placeholder="000.000.000-00" maxlength="14" data-js="cpf" required>
                    </div>
                </div>
                <div class="form-group"><label>RG</label><input type="text" name="rg" class="form-control" placeholder="00.000.000-X" maxlength="12" data-js="rg"></div>
            </div>

            <div class="form-section">
                <h2 class="section-title">Endereço e Contato</h2>
                <div class="form-row">
                    <div class="form-group">
                        <label class="required">CEP (Busca Automática)</label>
                        <input type="text" id="cep" class="form-control" placeholder="00000-000" maxlength="9" data-js="cep" required>
                        <small style="color:#666; font-size:0.8rem;">Pressione TAB após digitar</small>
                    </div>
                    <div class="form-group"><label class="required">Telefone</label><input type="tel" name="telefone" class="form-control" placeholder="(00) 00000-0000" maxlength="15" data-js="telefone" required></div>
                </div>
                <div class="form-group"><label class="required">Rua/Logradouro</label><input type="text" name="endereco" id="endereco" class="form-control" readonly required style="background-color: #f0f0f0;"></div>
                <div class="form-row">
                    <div class="form-group"><label class="required">Número</label><input type="text" name="numero" id="numero" class="form-control" required></div>
                    <div class="form-group"><label class="required">Bairro</label><input type="text" name="bairro" id="bairro" class="form-control" readonly required style="background-color: #f0f0f0;"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label class="required">Cidade</label><input type="text" name="cidade" id="cidade" class="form-control" readonly required style="background-color: #f0f0f0;"></div>
                    <div class="form-group"><label class="required">Estado</label><input type="text" name="estado" id="estado" class="form-control" readonly required style="background-color: #f0f0f0;"></div>
                </div>
                <input type="hidden" name="email" value="<?php echo $user_data['email']; ?>">
            </div>

            <div class="form-section">
                <h2 class="section-title">Esporte & Saúde</h2>
                <div class="form-group">
                    <label class="required">Modalidade</label>
                    <select name="modalidade" class="form-control" required>
                        <option value="">Selecione...</option>
                        <?php while($esp = $esportes_query->fetch_assoc()): ?>
                            <option value="<?php echo $esp['nome']; ?>"><?php echo $esp['nome']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="required">Horário Preferencial</label>
                    <select name="horario" class="form-control" required>
                        <option value="Manhã">Manhã</option><option value="Tarde">Tarde</option><option value="Noite">Noite</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="required">Atestado Médico (PDF)</label>
                    <input type="file" name="atestadoMedico" class="form-control" accept="application/pdf" required>
                    <small>Obrigatório para validação.</small>
                </div>
            </div>

            <div class="form-section">
                <h2 class="section-title">Emergência</h2>
                <div class="form-group"><label class="required">Nome Contato</label><input type="text" name="contatoEmergencia" class="form-control" required></div>
                <div class="form-row">
                    <div class="form-group"><label class="required">Telefone Emergência</label><input type="tel" name="telefoneEmergencia" class="form-control" maxlength="15" data-js="telefone" required></div>
                    <div class="form-group"><label class="required">Parentesco</label><input type="text" name="parentesco" class="form-control" required></div>
                </div>
            </div>

            <div class="form-section">
                <h2 class="section-title">Termo de Responsabilidade</h2>
                <div class="checkbox-group" style="align-items: center;">
                    <input type="checkbox" id="termosResponsabilidade" required>
                    <label for="termosResponsabilidade" class="checkbox-label">
                        Declaro que li e aceito o 
                        <a href="#" onclick="abrirModalTermo(event)" style="color:#e3a627; font-weight:bold; text-decoration:underline;">Termo de Responsabilidade e Uso de Imagem</a>.
                    </label>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">AVANÇAR</button>
            </div>
        </form>
    </div>

    <div class="modal-termo-overlay" id="modalTermo">
        <div class="modal-termo-content">
            <button class="modal-close-btn" onclick="fecharModalTermo()">&times;</button>
            <h2 style="color:#1e3a8a; margin-bottom:20px; border-bottom:2px solid #e3a627; padding-bottom:10px;">Termo de Responsabilidade</h2>
            
            <h3 style="font-size:1.1rem; color:#1e3a8a; margin-bottom:10px; font-weight:bold;">1. Autorização de Uso de Imagem</h3>
            <div class="termo-text">
                <p>Eu autorizo o uso, registro e publicação de minha imagem (ou do menor inscrito), em meio de comunicação, difusão digital, por Internet, televisão, rádio, bem como, todo e qualquer material, documentação visual, material promocional, merchandising ou cobertura cinematográfica de qualquer tipo pelo SAGE.</p>
                <br>
                <p>A autorização se aplica ao serviço operado pela Prefeitura de Santana de Parnaíba, eventos e competições, igualmente, o uso de meu nome, voz e biografia em consonância com eles, sem compensação ou ganho financeiro econômico para minha pessoa ou outrem que obtenha procuração por mim outorgada.</p>
            </div>

            <h3 style="font-size:1.1rem; color:#1e3a8a; margin-bottom:10px; font-weight:bold;">2. Ciência sobre Recomendação Médica</h3>
            <div class="termo-text">
                <p>Estou ciente de que é recomendável conversar com um médico antes de aumentar meu nível atual de atividade física, por ter respondido "Sim" a uma ou mais perguntas do Questionário de Prontidão para Atividade Física (PAR-Q).</p>
                <br>
                <p>Assumo plena responsabilidade por qualquer atividade física praticada sem o atendimento a essa recomendação. (Lei nº 9.197/2018)</p>
            </div>

            <button class="btn-primary" onclick="aceitarEFechar()" style="width:100%; margin-top:10px;">Li e Concordo</button>
        </div>
    </div>

    <script>
        // Função para abrir o modal do termo
        function abrirModalTermo(e) {
            e.preventDefault();
            document.getElementById('modalTermo').style.display = 'flex';
        }

        // Função para fechar o modal
        function fecharModalTermo() {
            document.getElementById('modalTermo').style.display = 'none';
        }

        // Função do botão "Li e Concordo" dentro do modal
        function aceitarEFechar() {
            document.getElementById('termosResponsabilidade').checked = true;
            fecharModalTermo();
        }

        // --- LÓGICA MÁSCARAS E VIACEP (Mantida do passo anterior) ---
        document.addEventListener('DOMContentLoaded', function() {
            const masks = {
                cpf(v) { return v.replace(/\D/g,'').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})/,'$1-$2').replace(/(-\d{2})\d+?$/,'$1'); },
                telefone(v) { return v.replace(/\D/g,'').replace(/(\d{2})(\d)/,'($1) $2').replace(/(\d{5})(\d)/,'$1-$2').replace(/(-\d{4})\d+?$/,'$1'); },
                cep(v) { return v.replace(/\D/g,'').replace(/(\d{5})(\d)/,'$1-$2').replace(/(-\d{3})\d+?$/,'$1'); },
                rg(v) { return v.replace(/\D/g,'').replace(/(\d{2})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1})/,'$1-$2'); }
            };

            document.querySelectorAll('input[data-js]').forEach(input => {
                input.addEventListener('input', e => { e.target.value = masks[input.dataset.js](e.target.value); });
            });

            const cepInput = document.getElementById('cep');
            if (cepInput) {
                cepInput.addEventListener('blur', function() {
                    let cep = this.value.replace(/\D/g, '');
                    if (cep.length === 8) {
                        document.getElementById('endereco').value = "Buscando...";
                        fetch(`https://viacep.com.br/ws/${cep}/json/`).then(r => r.json()).then(data => {
                            if (!data.erro) {
                                document.getElementById('endereco').value = data.logradouro;
                                document.getElementById('bairro').value = data.bairro;
                                document.getElementById('cidade').value = data.localidade;
                                document.getElementById('estado').value = data.uf;
                                document.getElementById('numero').focus();
                            } else { alert("CEP não encontrado."); }
                        }).catch(() => alert("Erro ao buscar CEP."));
                    }
                });
            }
        });
    </script>
</body>
</html>