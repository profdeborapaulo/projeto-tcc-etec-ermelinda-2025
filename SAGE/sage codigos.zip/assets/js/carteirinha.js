// carteirinha.js - Sistema Atualizado
console.log('🎫 carteirinha.js carregado! VERSÃO ATUALIZADA');

// Função principal de inicialização
function initializeCarteirinha() {
    console.log('🚀 Inicializando carteirinha...');
    
    // Carregar dados do usuário
    loadUserData();
    
    // Configurar eventos
    setupEventListeners();
    
    // Gerar QR Code
    generateQRCode();
    
    console.log('✅ Carteirinha inicializada com sucesso!');
}

function loadUserData() {
    console.log('📂 Carregando dados do usuário...');
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    // Calcular data de validade (6 meses após o termo)
    const dataValidade = calcularDataValidade(currentUser.dataTermo);
    
    // Preencher campos com dados do usuário
    const campos = {
        'nomeCompleto': currentUser.inscricao?.nomeCompleto || 'Maria Eduarda Silva Santos',
        'telefone': currentUser.inscricao?.telefone || '(11) 93390-0878',
        'dataNascimento': formatarData(currentUser.inscricao?.dataNascimento) || '10/09/2007',
        'cpf': formatarCPF(currentUser.inscricao?.cpf) || '545.279.438-12',
        'endereco': currentUser.inscricao?.endereco || 'Rua Japão, 317',
        'modalidade': currentUser.inscricao?.modalidade || 'Vôlei',
        'diasSemana': currentUser.inscricao?.diasSemana || 'Ter/Qui',
        'horario': currentUser.inscricao?.horario || '16:00h'
    };
    
    Object.keys(campos).forEach(key => {
        const field = document.getElementById(key);
        if (field) {
            field.value = campos[key];
        }
    });
    
    // Atualizar data de validade
    const dataValidadeElement = document.getElementById('dataValidade');
    if (dataValidadeElement) {
        dataValidadeElement.textContent = dataValidade;
    }
    
    // Verificar status da carteirinha
    verificarStatusCarteirinha(dataValidade);
    
    // Carregar foto se existir
    if (currentUser.fotoCarteirinha) {
        const fotoAluno = document.getElementById('fotoAluno');
        const fotoWrapper = document.querySelector('.foto-wrapper');
        if (fotoAluno) {
            fotoAluno.src = currentUser.fotoCarteirinha;
        }
        if (fotoWrapper) {
            fotoWrapper.classList.add('has-photo');
        }
        console.log('✅ Foto carregada do localStorage');
    }
}

function calcularDataValidade(dataTermo) {
    if (!dataTermo) {
        // Se não houver data do termo, usar 6 meses a partir de hoje
        const data = new Date();
        data.setMonth(data.getMonth() + 6);
        return formatarData(data);
    }
    
    try {
        const data = new Date(dataTermo);
        data.setMonth(data.getMonth() + 6);
        return formatarData(data);
    } catch (e) {
        console.error('Erro ao calcular data de validade:', e);
        const data = new Date();
        data.setMonth(data.getMonth() + 6);
        return formatarData(data);
    }
}

function verificarStatusCarteirinha(dataValidade) {
    const hoje = new Date();
    const dataVal = new Date(dataValidade.split('/').reverse().join('-'));
    const statusBadge = document.getElementById('statusBadge');
    
    if (!statusBadge) return;
    
    if (dataVal < hoje) {
        // Carteirinha vencida
        statusBadge.innerHTML = '<i class="fas fa-exclamation-circle"></i><span>VENCIDA</span>';
        statusBadge.style.background = 'var(--error)';
    } else if ((dataVal - hoje) / (1000 * 60 * 60 * 24) <= 30) {
        // Carteirinha prestes a vencer (30 dias ou menos)
        statusBadge.innerHTML = '<i class="fas fa-exclamation-triangle"></i><span>VENCE EM BREVE</span>';
        statusBadge.style.background = 'var(--warning)';
    } else {
        // Carteirinha válida
        statusBadge.innerHTML = '<i class="fas fa-check-circle"></i><span>VÁLIDA</span>';
        statusBadge.style.background = 'var(--success)';
    }
}

function setupEventListeners() {
    console.log('🔗 Configurando eventos...');
    
    // Botão Adicionar Foto
    const addPhotoBtn = document.getElementById('addPhotoBtn');
    const fotoInput = document.getElementById('fotoInput');
    
    if (addPhotoBtn && fotoInput) {
        addPhotoBtn.addEventListener('click', function() {
            console.log('📸 Clicou para adicionar foto');
            fotoInput.click();
        });
    }
    
    // Input de Foto
    if (fotoInput) {
        fotoInput.addEventListener('change', handleFotoUpload);
    }
    
    // Botões Imprimir
    const imprimirBtn = document.getElementById('imprimirBtn');
    const imprimirBtnMobile = document.getElementById('imprimirBtnMobile');
    
    if (imprimirBtn) {
        imprimirBtn.addEventListener('click', imprimirCarteirinha);
    }
    if (imprimirBtnMobile) {
        imprimirBtnMobile.addEventListener('click', imprimirCarteirinha);
    }
    
    // Botões Baixar PDF
    const baixarPdfBtn = document.getElementById('baixarPdfBtn');
    const baixarPdfBtnMobile = document.getElementById('baixarPdfBtnMobile');
    
    if (baixarPdfBtn) {
        baixarPdfBtn.addEventListener('click', baixarPDF);
    }
    if (baixarPdfBtnMobile) {
        baixarPdfBtnMobile.addEventListener('click', baixarPDF);
    }
    
    // Botão Alterar Foto
    const alterarBtn = document.getElementById('alterarFotoBtn');
    if (alterarBtn) {
        alterarBtn.addEventListener('click', function() {
            console.log('📸 Clicou para alterar foto');
            fotoInput.click();
        });
    }
    
    // Botão Editar Foto
    const editPhotoBtn = document.getElementById('editPhotoBtn');
    if (editPhotoBtn) {
        editPhotoBtn.addEventListener('click', function() {
            console.log('✏️ Clicou para editar foto');
            fotoInput.click();
        });
    }
    
    // Botão Remover Foto
    const removePhotoBtn = document.getElementById('removePhotoBtn');
    if (removePhotoBtn) {
        removePhotoBtn.addEventListener('click', removerFoto);
    }
    
    // Botão OK do Modal
    const modalBtn = document.getElementById('modalOkBtn');
    if (modalBtn) {
        modalBtn.addEventListener('click', closeSuccessModal);
    }
    
    // Drag and drop para foto
    setupDragAndDrop();
}

function setupDragAndDrop() {
    const fotoWrapper = document.getElementById('fotoWrapper');
    
    if (!fotoWrapper) return;
    
    fotoWrapper.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = 'var(--accent-gold)';
        this.style.backgroundColor = 'rgba(227, 166, 39, 0.1)';
    });
    
    fotoWrapper.addEventListener('dragleave', function(e) {
        e.preventDefault();
        this.style.borderColor = 'var(--accent-gold)';
        this.style.backgroundColor = 'var(--secondary-blue)';
    });
    
    fotoWrapper.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = 'var(--accent-gold)';
        this.style.backgroundColor = 'var(--secondary-blue)';
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFotoFile(files[0]);
        }
    });
}

function handleFotoUpload(event) {
    const file = event.target.files[0];
    if (file) {
        handleFotoFile(file);
    }
}

function handleFotoFile(file) {
    console.log('📁 Processando upload de foto...');
    
    if (!file) {
        console.log('❌ Nenhum arquivo selecionado');
        return;
    }
    
    console.log('📄 Arquivo selecionado:', file.name);
    
    // Validar tipo de arquivo
    if (!file.type.startsWith('image/')) {
        showNotification('Por favor, selecione um arquivo de imagem.', 'error');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const fotoDataUrl = e.target.result;
        console.log('✅ Foto carregada com sucesso');
        
        // Atualizar foto na carteirinha
        const fotoAluno = document.getElementById('fotoAluno');
        const fotoWrapper = document.querySelector('.foto-wrapper');
        
        if (fotoAluno) {
            fotoAluno.src = fotoDataUrl;
        }
        if (fotoWrapper) {
            fotoWrapper.classList.add('has-photo');
        }
        
        // Salvar no localStorage
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        currentUser.fotoCarteirinha = fotoDataUrl;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        console.log('✅ Foto salva no localStorage');
        
        // Mostrar modal de sucesso
        showSuccessModal();
        
        showNotification('Foto adicionada com sucesso!', 'success');
    };
    
    reader.onerror = function(error) {
        console.error('❌ Erro ao carregar foto:', error);
        showNotification('Erro ao carregar a foto. Tente novamente.', 'error');
    };
    
    reader.readAsDataURL(file);
}

function removerFoto() {
    console.log('🗑️ Removendo foto...');
    
    const fotoAluno = document.getElementById('fotoAluno');
    const fotoWrapper = document.querySelector('.foto-wrapper');
    
    if (fotoAluno) {
        fotoAluno.src = '/assets/img/user-placeholder.jpg';
    }
    if (fotoWrapper) {
        fotoWrapper.classList.remove('has-photo');
    }
    
    // Remover do localStorage
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    delete currentUser.fotoCarteirinha;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    showNotification('Foto removida com sucesso!', 'success');
}

function generateQRCode() {
    console.log('🔳 Gerando QR Code...');
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const qrContainer = document.getElementById('qrCode');
    
    if (!qrContainer) {
        console.error('❌ Container do QR Code não encontrado');
        return;
    }
    
    const dataValidade = calcularDataValidade(currentUser.dataTermo);
    
    const qrData = JSON.stringify({
        id: currentUser.id || 'USR' + Date.now(),
        nome: currentUser.inscricao?.nomeCompleto || 'Maria Eduarda Silva Santos',
        cpf: currentUser.inscricao?.cpf || '545.279.438-12',
        modalidade: currentUser.inscricao?.modalidade || 'Vôlei',
        validoAte: dataValidade
    });
    
    qrContainer.innerHTML = '';
    
    QRCode.toCanvas(qrData, { 
        width: 140, 
        height: 140, 
        margin: 1,
        color: { 
            dark: '#020D30', 
            light: '#FFFFFF' 
        }
    }, function(err, canvas) {
        if (err) {
            console.error('❌ Erro ao gerar QR Code:', err);
            createFallbackQRCode(qrContainer);
            return;
        }
        canvas.style.borderRadius = '8px';
        qrContainer.appendChild(canvas);
        console.log('✅ QR Code gerado com sucesso');
    });
}

function createFallbackQRCode(container) {
    container.innerHTML = `
        <div style="width: 140px; height: 140px; background: white; display: flex; align-items: center; justify-content: center; border-radius: 8px; border: 2px solid #e3a627;">
            <div style="text-align: center; color: #020D30; font-size: 12px; font-weight: bold;">
                <div>QR CODE</div>
                <div style="margin-top: 5px;">SAGE</div>
                <div style="margin-top: 5px; font-size: 10px;">CARTEIRINHA</div>
            </div>
        </div>
    `;
}

function imprimirCarteirinha() {
    console.log('🖨️ Iniciando impressão...');
    showNotification('Preparando impressão...', 'info');
    
    setTimeout(() => {
        window.print();
        showNotification('Impressão concluída!', 'success');
    }, 500);
}

function baixarPDF() {
    console.log('📥 Iniciando download do PDF...');
    showNotification('Gerando PDF...', 'info');
    
    const element = document.getElementById('carteirinhaCard');
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const nomeAluno = currentUser.inscricao?.nomeCompleto || 'carteirinha';
    const nomeArquivo = `carteirinha_${nomeAluno.replace(/\s+/g, '_')}.pdf`;
    
    const options = {
        margin: 10,
        filename: nomeArquivo,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    
    html2pdf().set(options).from(element).save().then(() => {
        console.log('✅ PDF gerado com sucesso');
        showNotification('PDF baixado com sucesso!', 'success');
    }).catch(error => {
        console.error('❌ Erro ao gerar PDF:', error);
        showNotification('Erro ao gerar PDF. Tente novamente.', 'error');
    });
}

function showSuccessModal() {
    console.log('🎉 Mostrando modal de sucesso');
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function closeSuccessModal() {
    console.log('❌ Fechando modal');
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function showNotification(message, type = 'info') {
    const container = document.getElementById('notificationContainer');
    if (!container) return;
    
    const existingNotification = container.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // Adicionar ícone baseado no tipo
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    
    notification.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 4000);
}

function formatarData(data) {
    if (!data) return '';
    
    try {
        const date = new Date(data);
        if (isNaN(date.getTime())) {
            return data;
        }
        return date.toLocaleDateString('pt-BR');
    } catch (e) {
        return data;
    }
}

function formatarCPF(cpf) {
    if (!cpf) return '';
    cpf = cpf.replace(/\D/g, '');
    return cpf.length === 11 ? cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : cpf;
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    console.log('🏁 DOM Carregado - Iniciando carteirinha...');
    initializeCarteirinha();
});

console.log('✅ Sistema de carteirinha atualizado carregado');