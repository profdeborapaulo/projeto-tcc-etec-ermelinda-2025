// inscricao.js - Sistema Completo de Navegação (CORRIGIDO)
document.addEventListener('DOMContentLoaded', function() {
    
    // --- 1. MÁSCARAS DE INPUT (CPF, Telefone, CEP, RG) ---
    const masks = {
        cpf(value) {
            return value
                .replace(/\D/g, '')
                .replace(/(\d{3})(\d)/, '$1.$2')
                .replace(/(\d{3})(\d)/, '$1.$2')
                .replace(/(\d{3})(\d{1,2})/, '$1-$2')
                .replace(/(-\d{2})\d+?$/, '$1');
        },
        telefone(value) {
            return value
                .replace(/\D/g, '')
                .replace(/(\d{2})(\d)/, '($1) $2')
                .replace(/(\d{5})(\d)/, '$1-$2')
                .replace(/(-\d{4})\d+?$/, '$1');
        },
        cep(value) {
            return value
                .replace(/\D/g, '')
                .replace(/(\d{5})(\d)/, '$1-$2')
                .replace(/(-\d{3})\d+?$/, '$1');
        },
        rg(value) {
            return value
                .replace(/\D/g, '')
                .replace(/(\d{2})(\d)/, '$1.$2')
                .replace(/(\d{3})(\d)/, '$1.$2')
                .replace(/(\d{3})(\d{1})/, '$1-$2');
        }
    };

    // Aplica as máscaras automaticamente nos campos com data-js
    document.querySelectorAll('input').forEach($input => {
        const field = $input.dataset.js; 
        if (field && masks[field]) {
            $input.addEventListener('input', (e) => {
                e.target.value = masks[field](e.target.value);
            }, false);
        }
    });

    // --- 2. VIACEP (Busca Automática) ---
    const cepInput = document.getElementById('cep');
    
    if (cepInput) {
        cepInput.addEventListener('blur', function() {
            // Remove caracteres não numéricos para a API
            const cep = this.value.replace(/\D/g, '');
            
            if (cep.length === 8) {
                // Feedback visual de carregamento
                document.getElementById('endereco').value = "Buscando...";
                document.getElementById('bairro').value = "...";
                document.getElementById('cidade').value = "...";
                
                fetch(`https://viacep.com.br/ws/${cep}/json/`)
                    .then(response => response.json())
                    .then(data => {
                        if (!data.erro) {
                            // Preenche os campos
                            document.getElementById('endereco').value = data.logradouro;
                            document.getElementById('bairro').value = data.bairro;
                            document.getElementById('cidade').value = data.localidade;
                            
                            // Tenta selecionar o estado automaticamente
                            const estadoSelect = document.getElementById('estado');
                            if(estadoSelect) {
                                estadoSelect.value = data.uf;
                            }
                            
                            // Foca no número para o usuário completar
                            document.getElementById('numero').focus();
                        } else {
                            alert("CEP não encontrado.");
                            limparEndereco();
                        }
                    })
                    .catch(() => {
                        alert("Erro ao buscar CEP. Verifique sua conexão.");
                        limparEndereco();
                    });
            }
        });
    }

    function limparEndereco() {
        document.getElementById('endereco').value = "";
        document.getElementById('bairro').value = "";
        document.getElementById('cidade').value = "";
        document.getElementById('estado').value = "";
    }
});
    document.querySelectorAll('input').forEach($input => {
        const field = $input.dataset.js; // Pega o atributo data-js
        if (field && masks[field]) {
            $input.addEventListener('input', (e) => {
                e.target.value = masks[field](e.target.value);
            }, false);
        }
    });

    // --- 2. VIACEP (Busca Automática) ---
    const cepInput = document.getElementById('cep');
    
    if (cepInput) {
        cepInput.addEventListener('blur', function() {
            const cep = this.value.replace(/\D/g, '');
            
            if (cep.length === 8) {
                // Feedback visual de carregamento
                document.getElementById('endereco').value = "Buscando...";
                
                fetch(`https://viacep.com.br/ws/${cep}/json/`)
                    .then(response => response.json())
                    .then(data => {
                        if (!data.erro) {
                            document.getElementById('endereco').value = data.logradouro;
                            document.getElementById('bairro').value = data.bairro;
                            document.getElementById('cidade').value = data.localidade;
                            
                            // Seleciona o estado automaticamente
                            const estadoSelect = document.getElementById('estado');
                            if(estadoSelect) {
                                estadoSelect.value = data.uf;
                            }
                            
                            // Foca no número para o usuário completar
                            document.getElementById('numero').focus();
                        } else {
                            alert("CEP não encontrado.");
                            limparEndereco();
                        }
                    })
                    .catch(() => {
                        alert("Erro ao buscar CEP.");
                        limparEndereco();
                    });
            }
        });
    }

    function limparEndereco() {
        document.getElementById('endereco').value = "";
        document.getElementById('bairro').value = "";
        document.getElementById('cidade').value = "";
    }
});

function initializeInscricao() {
    const form = document.getElementById('inscricaoForm');
    
    console.log('🔍 Verificando estado da aplicação...');
    
    // PRIMEIRO: Verificar se está voltando do termo
    if (checkReturnFromTermo()) {
        // Se está voltando do termo, restaurar dados do cache
        restoreFromCache();
    } else {
        // Se não, carregar dados normais
        loadUserData();
    }
    
    // Inicializar validação em tempo real
    initializeRealTimeValidation();
    
    // Inicializar máscaras
    initializeMasks();
    
    // Atualizar progresso inicial
    updateProgress();
    
    // CONFIGURAR LINKS DO TERMO DE RESPONSABILIDADE
    setupTermoResponsabilidadeLinks();
    
    // CONFIGURAR LINKS DOS TERMOS E POLÍTICA
    setupTermosLinks();
    
    // Evento de submit do formulário (FINALIZAR)
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('🎯 Finalizando inscrição...');
        
        if (validateForm()) {
            finalizarInscricao();
        } else {
            showNotification('Por favor, preencha todos os campos obrigatórios', 'error');
        }
    });
    
    // Salvar automaticamente enquanto digita
    form.addEventListener('input', function() {
        updateProgress();
        autoSaveFormData();
    });
    
    // Botão continuar do modal
    document.getElementById('continueBtn').addEventListener('click', function() {
        window.location.href = '/assets/pages/questionario.html';
    });
    
    // Salvar dados imediatamente ao carregar (backup)
    setTimeout(() => {
        saveToCache();
    }, 500);
}

// SISTEMA DE CACHE ROBUSTO - CORRIGIDO
function saveToCache() {
    const formData = new FormData(document.getElementById('inscricaoForm'));
    const inscricaoData = {};
    
    for (let [key, value] of formData.entries()) {
        inscricaoData[key] = value;
    }
    
    // Adicionar checkboxes
    inscricaoData.autorizacaoImagem = document.getElementById('autorizacaoImagem')?.checked || false;
    inscricaoData.termosResponsabilidade = document.getElementById('termosResponsabilidade')?.checked || false;
    
    // Salvar no sessionStorage para persistência imediata
    sessionStorage.setItem('inscricaoCache', JSON.stringify(inscricaoData));
    console.log('💾 Cache salvo:', inscricaoData);
}

function restoreFromCache() {
    const cache = sessionStorage.getItem('inscricaoCache');
    if (cache) {
        console.log('🔄 Restaurando dados do cache...');
        const inscricaoData = JSON.parse(cache);
        
        Object.keys(inscricaoData).forEach(key => {
            const field = document.getElementById(key);
            if (field) {
                if (field.type === 'checkbox') {
                    field.checked = inscricaoData[key];
                } else {
                    field.value = inscricaoData[key];
                }
            }
        });
        
        // Marcar checkbox do termo se voltou do termo
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if (currentUser.termoPreenchido) {
            const termosCheckbox = document.getElementById('termosResponsabilidade');
            if (termosCheckbox) {
                termosCheckbox.checked = true;
                console.log('✅ Checkbox do termo marcado automaticamente');
                
                // Validar o checkbox
                validateCheckboxField(termosCheckbox);
            }
            
            // Limpar flag
            delete currentUser.termoPreenchido;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
        }
        
        // Validar e atualizar após um pequeno delay para garantir que os campos foram renderizados
        setTimeout(() => {
            validateAllFields();
            updateProgress();
            
            // NÃO LIMPAR O CACHE AQUI - manter para possíveis recargas
            console.log('✅ Dados restaurados e validados');
        }, 300);
        
        showNotification('Dados restaurados com sucesso!', 'success');
        
        return true;
    }
    return false;
}

// CONFIGURAR LINKS DO TERMO DE RESPONSABILIDADE - CORRIGIDO
function setupTermoResponsabilidadeLinks() {
    const termoLinks = document.querySelectorAll('a.termo-link, a[href*="termo.html"]');
    
    termoLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('📝 Salvando dados antes de ir para o Termo de Responsabilidade...');
            
            // Validar se o formulário está minimamente preenchido
            if (!validateMinimumForm()) {
                showNotification('Preencha os campos obrigatórios básicos antes de continuar', 'error');
                return;
            }
            
            // Salvar dados atuais no cache
            saveToCache();
            
            // Marcar que estamos indo para o termo
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            currentUser.indoParaTermo = true;
            currentUser.termoOrigem = 'inscricao';
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            console.log('➡️ Navegando para o Termo de Responsabilidade...');
            window.location.href = this.href;
        });
    });
}

// VALIDAÇÃO MÍNIMA DO FORMULÁRIO
function validateMinimumForm() {
    const requiredFields = ['nomeCompleto', 'cpf', 'dataNascimento', 'email'];
    let isValid = true;
    
    requiredFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field && field.hasAttribute('required') && !field.value.trim()) {
            isValid = false;
            // Destacar campo não preenchido
            const formGroup = field.closest('.form-group');
            if (formGroup) {
                formGroup.classList.add('error');
                showFieldError(formGroup, 'Campo obrigatório');
            }
        }
    });
    
    return isValid;
}

// CONFIGURAR LINKS DOS TERMOS E POLÍTICA
function setupTermosLinks() {
    // Links dos Termos de Uso
    const termosLinks = document.querySelectorAll('a.termos-link, a[href*="termos-uso.html"]');
    termosLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Salvar dados atuais
            saveToCache();
            
            // Marcar que estamos indo para os termos
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            currentUser.indoParaTermos = true;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            console.log('➡️ Navegando para Termos de Uso...');
            window.location.href = this.href;
        });
    });
    
    // Links da Política de Privacidade
    const politicaLinks = document.querySelectorAll('a.politica-link, a[href*="politica-privacidade.html"]');
    politicaLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Salvar dados atuais
            saveToCache();
            
            // Marcar que estamos indo para a política
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            currentUser.indoParaPolitica = true;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            console.log('➡️ Navegando para Política de Privacidade...');
            window.location.href = this.href;
        });
    });
}

// VERIFICAR SE ESTÁ VOLTANDO DO TERMO - CORRIGIDO
function checkReturnFromTermo() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (currentUser.voltandoDoTermo) {
        console.log('🔄 VOLTANDO DO TERMO detectado');
        console.log('📋 Dados do usuário:', currentUser);
        
        // Limpar flag imediatamente
        delete currentUser.voltandoDoTermo;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        return true;
    }
    
    return false;
}

// CARREGAR DADOS DO USUÁRIO - CORRIGIDO
function loadUserData() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (currentUser.inscricao) {
        console.log('📂 Carregando dados da inscrição do localStorage');
        
        Object.keys(currentUser.inscricao).forEach(key => {
            const field = document.getElementById(key);
            if (field) {
                if (field.type === 'checkbox') {
                    field.checked = currentUser.inscricao[key];
                } else {
                    field.value = currentUser.inscricao[key];
                }
            }
        });
        
        // Verificar se o termo foi preenchido e marcar o checkbox
        if (currentUser.termoCompleted) {
            const termosCheckbox = document.getElementById('termosResponsabilidade');
            if (termosCheckbox) {
                termosCheckbox.checked = true;
                console.log('✅ Checkbox do termo marcado (termo já preenchido)');
                validateCheckboxField(termosCheckbox);
            }
        }
        
        // Validar e atualizar progresso
        setTimeout(() => {
            validateAllFields();
            updateProgress();
        }, 100);
    }
}

// VALIDAÇÃO DE CHECKBOX - NOVA FUNÇÃO
function validateCheckboxField(checkbox) {
    const checkboxGroup = checkbox.closest('.checkbox-group');
    if (checkboxGroup) {
        if (checkbox.checked) {
            checkboxGroup.classList.remove('error');
            checkboxGroup.style.background = '';
            clearFieldError(checkboxGroup);
        } else {
            checkboxGroup.classList.add('error');
            checkboxGroup.style.background = '#ffe6e6';
        }
    }
}

// SALVAR DADOS DA INSCRIÇÃO - CORRIGIDO
function saveInscricaoData() {
    const formData = new FormData(document.getElementById('inscricaoForm'));
    const inscricaoData = {};
    
    for (let [key, value] of formData.entries()) {
        inscricaoData[key] = value;
    }
    
    // Adicionar checkboxes
    inscricaoData.autorizacaoImagem = document.getElementById('autorizacaoImagem')?.checked || false;
    inscricaoData.termosResponsabilidade = document.getElementById('termosResponsabilidade')?.checked || false;
    
    // Salvar no localStorage
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    currentUser.inscricao = inscricaoData;
    
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    console.log('💾 Dados da inscrição salvos:', inscricaoData);
}

// FINALIZAR INSCRIÇÃO E IR PARA QUESTIONÁRIO
function finalizarInscricao() {
    console.log('✅ Finalizando inscrição e indo para questionário...');
    
    // Verificar se o termo foi preenchido
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    if (!currentUser.termoCompleted) {
        showNotification('É necessário preencher o Termo de Responsabilidade antes de finalizar', 'error');
        return;
    }
    
    // Salvar dados finais
    saveInscricaoData();
    
    // Marcar inscrição como completa
    currentUser.inscricaoCompleted = true;
    currentUser.inscricaoFinalizada = true;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    // Mostrar modal de sucesso
    showSuccessModal();
}

// SALVAMENTO AUTOMÁTICO - CORRIGIDO
function autoSaveFormData() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    // Só salvar automaticamente se não estiver no meio do processo de restauração
    if (!currentUser.voltandoDoTermo) {
        saveInscricaoData();
        saveToCache(); // Também atualizar o cache
    }
}

// VALIDAR TODOS OS CAMPOS - CORRIGIDO
function validateAllFields() {
    const fields = document.querySelectorAll('input, select');
    fields.forEach(field => {
        if (field.value.trim() !== '' || field.checked) {
            validateField(field);
        }
    });
    
    // Validar checkboxes especificamente
    const checkboxes = document.querySelectorAll('input[type="checkbox"][required]');
    checkboxes.forEach(checkbox => {
        validateCheckboxField(checkbox);
    });
}

function initializeRealTimeValidation() {
    const fields = document.querySelectorAll('input, select');
    
    fields.forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });
        
        field.addEventListener('input', function() {
            if (this.value.trim() !== '') {
                clearFieldError(this);
            }
        });
        
        // Para checkboxes
        if (field.type === 'checkbox') {
            field.addEventListener('change', function() {
                validateCheckboxField(this);
                updateProgress();
            });
        }
    });
}

function initializeMasks() {
    // Máscara para CPF
    const cpfInput = document.getElementById('cpf');
    if (cpfInput) {
        cpfInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length <= 11) {
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                e.target.value = value;
            }
        });
    }
    
    // Máscara para telefone
    const phoneInput = document.getElementById('telefone');
    const emergencyPhoneInput = document.getElementById('telefoneEmergencia');
    
    [phoneInput, emergencyPhoneInput].forEach(input => {
        if (input) {
            input.addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length <= 11) {
                    value = value.replace(/(\d{2})(\d)/, '($1) $2');
                    value = value.replace(/(\d{5})(\d)/, '$1-$2');
                    e.target.value = value;
                }
            });
        }
    });
}

function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    switch(field.type) {
        case 'email':
            if (value && !isValidEmail(value)) {
                isValid = false;
                errorMessage = 'Email inválido';
            }
            break;
        case 'tel':
            if (value && !isValidPhone(value)) {
                isValid = false;
                errorMessage = 'Telefone inválido';
            }
            break;
        case 'text':
            if (field.id === 'cpf' && value && !isValidCPF(value)) {
                isValid = false;
                errorMessage = 'CPF inválido';
            }
            break;
        case 'date':
            if (value && !isValidDate(value)) {
                isValid = false;
                errorMessage = 'Data inválida';
            }
            break;
    }
    
    if (field.hasAttribute('required') && value === '') {
        isValid = false;
        errorMessage = 'Este campo é obrigatório';
    }
    
    if (field.tagName === 'SELECT' && field.hasAttribute('required') && value === '') {
        isValid = false;
        errorMessage = 'Selecione uma opção';
    }
    
    const formGroup = field.closest('.form-group');
    if (formGroup) {
        if (!isValid) {
            showFieldError(formGroup, errorMessage);
            formGroup.classList.add('error');
            formGroup.classList.remove('valid');
        } else {
            clearFieldError(formGroup);
            formGroup.classList.remove('error');
            if (value !== '') {
                formGroup.classList.add('valid');
            }
        }
    }
    
    return isValid;
}

function validateForm() {
    const requiredFields = document.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    const requiredCheckboxes = document.querySelectorAll('input[type="checkbox"][required]');
    requiredCheckboxes.forEach(checkbox => {
        if (!checkbox.checked) {
            isValid = false;
            validateCheckboxField(checkbox);
        }
    });
    
    return isValid;
}

function updateProgress() {
    const requiredFields = document.querySelectorAll('input[required], select[required]');
    const requiredCheckboxes = document.querySelectorAll('input[type="checkbox"][required]');
    const allRequired = [...requiredFields, ...requiredCheckboxes];
    
    const filledFields = allRequired.filter(field => {
        if (field.type === 'checkbox') {
            return field.checked;
        } else {
            return field.value.trim() !== '' && validateField(field);
        }
    });
    
    const progress = (filledFields.length / allRequired.length) * 100;
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    
    if (progressBar) {
        progressBar.style.width = `${progress}%`;
    }
    
    if (progressText) {
        progressText.textContent = `${Math.round(progress)}% completo`;
    }
}

function showSuccessModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'flex';
    
    setTimeout(() => {
        modal.querySelector('.modal-content').style.transform = 'scale(1)';
        modal.querySelector('.modal-content').style.opacity = '1';
    }, 100);
}

function showFieldError(formGroup, message) {
    clearFieldError(formGroup);
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.color = '#dc3545';
    errorDiv.style.fontSize = '0.875rem';
    errorDiv.style.marginTop = '0.25rem';
    
    formGroup.appendChild(errorDiv);
}

function clearFieldError(formGroup) {
    const errorDiv = formGroup.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

function showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
    `;
    
    if (type === 'success') {
        notification.style.background = '#27ae60';
    } else if (type === 'error') {
        notification.style.background = '#e74c3c';
    } else {
        notification.style.background = '#3498db';
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
    return phoneRegex.test(phone);
}

function isValidCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');
    return cpf.length === 11;
}

function isValidDate(dateString) {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date);
}

const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .modal-content {
        transition: all 0.3s ease;
        transform: scale(0.9);
        opacity: 0;
    }
`;
document.head.appendChild(style);