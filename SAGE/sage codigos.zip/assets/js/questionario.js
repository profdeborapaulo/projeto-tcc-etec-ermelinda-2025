// questionario.js - Sistema Completo do Questionário PAR-Q
document.addEventListener('DOMContentLoaded', function() {
    console.log('📋 Página do Questionário PAR-Q carregada');
    initializeQuestionario();
});

function initializeQuestionario() {
    // Elementos DOM
    const questionarioForm = document.getElementById('questionarioForm');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const alertaMedico = document.getElementById('alertaMedico');
    const resultadoSection = document.getElementById('resultadoSection');
    const resultadoCard = document.getElementById('resultadoCard');
    const resultadoIcon = document.getElementById('resultadoIcon');
    const resultadoTitulo = document.getElementById('resultadoTitulo');
    const resultadoDescricao = document.getElementById('resultadoDescricao');
    const resultadoDetalhes = document.getElementById('resultadoDetalhes');
    const limparBtn = document.getElementById('limparBtn');
    const confirmModal = document.getElementById('confirmModal');
    const modalConfirmBtn = document.getElementById('modalConfirmBtn');

    // Configuração inicial
    let respostasPositivas = [];

    // Carregar dados salvos se existirem
    loadSavedData();

    // Event Listeners
    questionarioForm.addEventListener('change', updateProgress);
    questionarioForm.addEventListener('change', checkMedicalAlert);
    questionarioForm.addEventListener('submit', handleFormSubmit);
    limparBtn.addEventListener('click', limparRespostas);
    modalConfirmBtn.addEventListener('click', closeConfirmationModal);

    // Fechar modal ao clicar fora
    window.addEventListener('click', function(event) {
        if (event.target === confirmModal) {
            closeConfirmationModal();
        }
    });

    // Atualizar progresso inicial
    updateProgress();

    console.log('✅ Questionário inicializado');
}

// FUNÇÃO: Atualizar progresso
function updateProgress() {
    const totalQuestions = 7;
    const answeredQuestions = document.querySelectorAll('input[type="radio"]:checked').length;
    const progress = Math.min(100, Math.round((answeredQuestions / totalQuestions) * 100));
    
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    
    progressFill.style.width = `${progress}%`;
    progressText.textContent = `${progress}% completo`;

    // Atualizar estado visual das questões respondidas
    document.querySelectorAll('.question').forEach(question => {
        const radioName = question.querySelector('input[type="radio"]').name;
        const answered = document.querySelector(`input[name="${radioName}"]:checked`);
        
        if (answered) {
            question.classList.add('answered');
        } else {
            question.classList.remove('answered');
        }
    });

    // Calcular resultado se todas as questões foram respondidas
    if (answeredQuestions === totalQuestions) {
        calcularResultado();
    } else {
        document.getElementById('resultadoSection').style.display = 'none';
    }

    // Salvar dados automaticamente
    saveQuestionarioData();
}

// FUNÇÃO: Verificar alerta médico
function checkMedicalAlert() {
    const questions = [
        'problemaCoracao',
        'dorPeitoAtividade', 
        'dorPeitoUltimoMes',
        'tonturaPerdaConsciencia',
        'problemaOsseoArticular',
        'medicamentoPressao',
        'outraRazao'
    ];

    const respostasPositivas = questions.filter(question => {
        const selected = document.querySelector(`input[name="${question}"]:checked`);
        return selected && selected.value === 'sim';
    });

    const alertaMedico = document.getElementById('alertaMedico');
    if (respostasPositivas.length > 0) {
        alertaMedico.style.display = 'flex';
    } else {
        alertaMedico.style.display = 'none';
    }

    return respostasPositivas;
}

// FUNÇÃO: Calcular resultado
function calcularResultado() {
    const todasQuestoes = document.querySelectorAll('input[type="radio"]:checked');
    const respostasSim = Array.from(todasQuestoes).filter(radio => radio.value === 'sim').length;
    const respostasPositivas = checkMedicalAlert();

    const resultadoSection = document.getElementById('resultadoSection');
    const resultadoIcon = document.getElementById('resultadoIcon');
    const resultadoTitulo = document.getElementById('resultadoTitulo');
    const resultadoDescricao = document.getElementById('resultadoDescricao');
    const resultadoDetalhes = document.getElementById('resultadoDetalhes');
    const resultadoCard = document.getElementById('resultadoCard');

    resultadoSection.style.display = 'block';

    if (respostasSim === 0) {
        // Apto para atividade física
        resultadoIcon.textContent = '✅';
        resultadoTitulo.textContent = 'Apto para Atividade Física';
        resultadoDescricao.textContent = 'Parabéns! Com base nas suas respostas, você está apto para iniciar atividades físicas.';
        resultadoDetalhes.innerHTML = `
            <p><strong>Recomendações:</strong></p>
            <ul>
                <li>Inicie as atividades gradualmente</li>
                <li>Mantenha-se hidratado durante os exercícios</li>
                <li>Respeite seus limites físicos</li>
                <li>Use roupas e calçados adequados</li>
            </ul>
        `;
        resultadoCard.style.borderColor = '#10b981';
    } else {
        // Necessita avaliação médica
        resultadoIcon.textContent = '⚠️';
        resultadoTitulo.textContent = 'Avaliação Médica Recomendada';
        resultadoDescricao.textContent = 'Recomendamos que consulte um médico antes de iniciar atividades físicas.';
        resultadoDetalhes.innerHTML = `
            <p><strong>Motivos identificados:</strong></p>
            <ul>
                ${respostasPositivas.map(questao => {
                    const nomeQuestao = getNomeQuestao(questao);
                    return `<li>${nomeQuestao}</li>`;
                }).join('')}
            </ul>
            <p><strong>Próximos passos:</strong></p>
            <ul>
                <li>Agende uma consulta com um médico</li>
                <li>Compartilhe este questionário com o profissional</li>
                <li>Siga as orientações médicas</li>
                <li>Retorne após a avaliação</li>
            </ul>
        `;
        resultadoCard.style.borderColor = '#e3a627';
    }
}

// FUNÇÃO: Obter nome da questão
function getNomeQuestao(questao) {
    const nomes = {
        'problemaCoracao': 'Problema cardíaco identificado',
        'dorPeitoAtividade': 'Dor no peito durante atividade física',
        'dorPeitoUltimoMes': 'Dor no peito no último mês',
        'tonturaPerdaConsciencia': 'Tontura ou perda de consciência',
        'problemaOsseoArticular': 'Problema ósseo ou articular',
        'medicamentoPressao': 'Uso de medicamento para pressão/coração',
        'outraRazao': 'Outra razão para não praticar atividade física'
    };
    return nomes[questao] || questao;
}

// FUNÇÃO: Validar formulário
function validateForm() {
    let isValid = true;
    const questions = document.querySelectorAll('.question');

    // Limpar estados de erro
    questions.forEach(question => {
        question.classList.remove('invalid');
        const error = question.querySelector('.error-message');
        if (error) error.remove();
    });

    // Validar se todas as questões foram respondidas
    const totalQuestions = 7;
    const answeredQuestions = document.querySelectorAll('input[type="radio"]:checked').length;

    if (answeredQuestions < totalQuestions) {
        // Encontrar primeira questão não respondida
        const firstUnanswered = document.querySelector('.question:not(.answered)');
        if (firstUnanswered) {
            markAsInvalid(firstUnanswered, 'Por favor, responda esta questão antes de continuar');
            firstUnanswered.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        isValid = false;
    }

    return isValid;
}

// FUNÇÃO: Marcar como inválido
function markAsInvalid(element, message) {
    element.classList.add('invalid');
    
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    
    element.appendChild(errorElement);
}

// FUNÇÃO: Manipular envio do formulário
function handleFormSubmit(e) {
    e.preventDefault();
    
    if (validateForm()) {
        submitQuestionario();
    } else {
        showNotification('Por favor, responda todas as questões antes de continuar', 'error');
    }
}

// FUNÇÃO: Submeter questionário
function submitQuestionario() {
    const formData = new FormData(document.getElementById('questionarioForm'));
    const data = Object.fromEntries(formData.entries());

    // Simular envio para o servidor
    const submitBtn = document.querySelector('.btn-primary');
    const originalText = submitBtn.textContent;

    submitBtn.disabled = true;
    submitBtn.textContent = 'Processando...';

    setTimeout(() => {
        console.log('📊 Respostas do PAR-Q:', data);
        
        // Salvar dados finais
        saveQuestionarioData();
        
        // Mostrar modal de confirmação
        showConfirmationModal();
        
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
    }, 1500);
}

// FUNÇÃO: Mostrar modal de confirmação
function showConfirmationModal() {
    const respostasPositivas = checkMedicalAlert();
    const hasHealthConcerns = respostasPositivas.length > 0;

    const modalIcon = document.getElementById('modalIcon');
    const modalTitle = document.getElementById('modalTitle');
    const modalText = document.getElementById('modalText');
    const modalSubtext = document.getElementById('modalSubtext');

    if (hasHealthConcerns) {
        modalIcon.textContent = '⚠️';
        modalTitle.textContent = 'Questionário Concluído';
        modalText.textContent = 'Suas respostas foram registradas.';
        modalSubtext.textContent = 'Recomendamos consulta médica antes de iniciar atividades físicas.';
    } else {
        modalIcon.textContent = '✅';
        modalTitle.textContent = 'Questionário Concluído!';
        modalText.textContent = 'Suas respostas foram registradas com sucesso.';
        modalSubtext.textContent = 'Você será redirecionado para a carteirinha.';
    }

    document.getElementById('confirmModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

// FUNÇÃO: Fechar modal de confirmação
function closeConfirmationModal() {
    document.getElementById('confirmModal').style.display = 'none';
    document.body.style.overflow = 'auto';
    
    // CORREÇÃO: Redirecionar para CARTEIRINHA em vez do termo
    setTimeout(() => {
        console.log('➡️ Redirecionando para a carteirinha...');
        
        // Salvar estado de conclusão do questionário
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        currentUser.questionarioCompleted = true;
        currentUser.questionarioDate = new Date().toISOString();
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Redirecionar para carteirinha
        window.location.href = '/assets/pages/carteirinha.html';
    }, 500);
}

// FUNÇÃO: Limpar respostas
function limparRespostas() {
    if (confirm('Tem certeza que deseja limpar todas as respostas?')) {
        // Limpar todos os radios
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.checked = false;
        });
        
        // Resetar estados visuais
        document.querySelectorAll('.question').forEach(question => {
            question.classList.remove('answered', 'invalid');
            const error = question.querySelector('.error-message');
            if (error) error.remove();
        });
        
        // Resetar progresso
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        progressFill.style.width = '0%';
        progressText.textContent = '0% completo';
        
        // Ocultar alertas e resultados
        document.getElementById('alertaMedico').style.display = 'none';
        document.getElementById('resultadoSection').style.display = 'none';
        
        // Limpar dados salvos
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        delete currentUser.questionario;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        showNotification('Respostas limpas com sucesso', 'success');
    }
}

// FUNÇÃO: Salvar dados do questionário
function saveQuestionarioData() {
    const formData = new FormData(document.getElementById('questionarioForm'));
    const questionarioData = {};
    
    for (let [key, value] of formData.entries()) {
        questionarioData[key] = value;
    }
    
    // Adicionar informações adicionais
    questionarioData.hasHealthIssues = checkMedicalAlert().length > 0;
    questionarioData.timestamp = new Date().toISOString();
    
    // Salvar no localStorage
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    currentUser.questionario = questionarioData;
    currentUser.questionarioCompleted = true;
    
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    console.log('💾 Dados do questionário salvos:', questionarioData);
}

// FUNÇÃO: Carregar dados salvos
function loadSavedData() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (currentUser.questionario) {
        console.log('📂 Carregando dados do questionário do localStorage');
        
        Object.keys(currentUser.questionario).forEach(key => {
            if (key !== 'hasHealthIssues' && key !== 'timestamp') {
                const value = currentUser.questionario[key];
                const field = document.querySelector(`[name="${key}"][value="${value}"]`);
                
                if (field) {
                    field.checked = true;
                }
            }
        });
        
        // Atualizar interface após carregar dados
        setTimeout(() => {
            updateProgress();
            checkMedicalAlert();
        }, 100);
    }
}

// FUNÇÃO: Mostrar notificação
function showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
    `;
    
    if (type === 'success') {
        notification.style.background = '#10b981';
    } else if (type === 'error') {
        notification.style.background = '#dc2626';
    } else {
        notification.style.background = '#3b82f6';
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Adicionar estilos para notificações
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
`;
document.head.appendChild(style);