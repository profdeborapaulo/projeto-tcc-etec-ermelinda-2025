document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 Página do Termo de Responsabilidade carregada');
    initializeTermo();
});

function initializeTermo() {
    const form = document.getElementById('termoForm');
    
    console.log('🔍 Verificando origem...');
    checkOrigem();
    
    // Carregar dados salvos se existirem
    loadSavedData();
    
    // Inicializar validação em tempo real
    initializeRealTimeValidation();
    
    // Verificar respostas de saúde
    checkHealthResponses();
    
    // Evento de submit do formulário
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('📝 Formulário do termo submetido');
        
        if (validateForm()) {
            saveTermoData();
            showSuccessModal();
        } else {
            showNotification('Por favor, responda todas as questões obrigatórias', 'error');
        }
    });
    
    // Evento para verificar respostas de saúde
    form.addEventListener('change', function(e) {
        if (e.target.name && e.target.name !== 'autorizacaoImagem' && e.target.name !== 'cienciaRecomendacao') {
            checkHealthResponses();
        }
    });
    
    // BOTÃO CONTINUAR DO MODAL - Volta para inscrição
    document.getElementById('continueBtn').addEventListener('click', function() {
        voltarParaInscricao();
    });
    
    // Salvar dados do termo enquanto preenche
    form.addEventListener('change', function() {
        saveTempTermoData();
    });
}

// FUNÇÃO: Voltar para inscrição
function voltarParaInscricao() {
    console.log('🔄 Voltando para inscrição...');
    
    // Salvar dados do termo
    saveTermoData();
    
    // Marcar que estamos voltando do termo e preservar dados da inscrição
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const inscricaoData = JSON.parse(localStorage.getItem('inscricaoData') || '{}');
    
    // Preservar todos os dados da inscrição
    currentUser.voltandoDoTermo = true;
    currentUser.termoPreenchido = true;
    currentUser.dadosInscricao = inscricaoData; // Preserva dados da inscrição
    
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    console.log('📍 Redirecionando para inscrição...');
    console.log('💾 Dados preservados:', inscricaoData);
    
    // Usar o mesmo método dos outros termos
    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = '/assets/pages/inscricao.html';
    }
}

// FUNÇÃO: Verificar origem
function checkOrigem() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (currentUser.termoOrigem === 'inscricao') {
        console.log('✅ Vindo da inscrição - fluxo correto');
    } else {
        console.log('⚠️ Acesso direto ao termo - configurando volta para inscrição');
        currentUser.termoOrigem = 'inscricao';
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
}

// FUNÇÃO: Salvar dados temporários do termo
function saveTempTermoData() {
    const formData = new FormData(document.getElementById('termoForm'));
    const termoData = {};
    
    for (let [key, value] of formData.entries()) {
        termoData[key] = value;
    }
    
    // Salvar dados temporários
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    currentUser.termoTemp = termoData;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    console.log('💾 Dados temporários do termo salvos');
}

function initializeRealTimeValidation() {
    const radioGroups = document.querySelectorAll('.options');
    const checkboxes = document.querySelectorAll('input[type="checkbox"][required]');
    
    // Validar grupos de rádio
    radioGroups.forEach(group => {
        const radios = group.querySelectorAll('input[type="radio"]');
        radios.forEach(radio => {
            radio.addEventListener('change', function() {
                validateRadioGroup(this.name);
            });
        });
    });
    
    // Validar checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            validateCheckbox(this);
        });
    });
}

function validateRadioGroup(groupName) {
    const radios = document.querySelectorAll(`input[name="${groupName}"]`);
    const question = radios[0].closest('.question');
    let hasSelection = false;
    
    radios.forEach(radio => {
        if (radio.checked) {
            hasSelection = true;
        }
    });
    
    if (question) {
        if (hasSelection) {
            question.classList.remove('error');
            clearFieldError(question);
        } else {
            question.classList.add('error');
            showFieldError(question, 'Esta pergunta é obrigatória');
        }
    }
    
    return hasSelection;
}

function validateCheckbox(checkbox) {
    const checkboxGroup = checkbox.closest('.checkbox-group');
    
    if (checkboxGroup) {
        if (checkbox.checked) {
            checkboxGroup.classList.remove('error');
            clearFieldError(checkboxGroup);
        } else {
            checkboxGroup.classList.add('error');
            showFieldError(checkboxGroup, 'Esta autorização é obrigatória');
        }
    }
    
    return checkbox.checked;
}

function checkHealthResponses() {
    const healthQuestions = [
        'problemaCoracao',
        'dorPeito', 
        'dorPeitoUltimoMes',
        'tontura',
        'problemaArticular',
        'medicamento',
        'outraRazao'
    ];
    
    let hasHealthIssue = false;
    
    healthQuestions.forEach(questionName => {
        const simRadio = document.querySelector(`input[name="${questionName}"][value="sim"]`);
        if (simRadio && simRadio.checked) {
            hasHealthIssue = true;
        }
    });
    
    const alertaMedico = document.getElementById('alertaMedico');
    if (alertaMedico) {
        if (hasHealthIssue) {
            alertaMedico.style.display = 'flex';
        } else {
            alertaMedico.style.display = 'none';
        }
    }
    
    return hasHealthIssue;
}

function validateForm() {
    let isValid = true;
    
    // Validar todas as questões de rádio
    const radioGroups = document.querySelectorAll('.question');
    radioGroups.forEach(question => {
        const radios = question.querySelectorAll('input[type="radio"]');
        let groupValid = false;
        
        radios.forEach(radio => {
            if (radio.checked) {
                groupValid = true;
            }
        });
        
        if (!groupValid) {
            isValid = false;
            question.classList.add('error');
            showFieldError(question, 'Esta pergunta é obrigatória');
        } else {
            question.classList.remove('error');
            clearFieldError(question);
        }
    });
    
    // Validar checkboxes obrigatórios
    const requiredCheckboxes = document.querySelectorAll('input[type="checkbox"][required]');
    requiredCheckboxes.forEach(checkbox => {
        if (!checkbox.checked) {
            isValid = false;
            const checkboxGroup = checkbox.closest('.checkbox-group');
            if (checkboxGroup) {
                checkboxGroup.classList.add('error');
                showFieldError(checkboxGroup, 'Esta autorização é obrigatória');
            }
        } else {
            const checkboxGroup = checkbox.closest('.checkbox-group');
            if (checkboxGroup) {
                checkboxGroup.classList.remove('error');
                clearFieldError(checkboxGroup);
            }
        }
    });
    
    return isValid;
}

function saveTermoData() {
    const formData = new FormData(document.getElementById('termoForm'));
    const termoData = {};
    
    for (let [key, value] of formData.entries()) {
        termoData[key] = value;
    }
    
    // Adicionar informações adicionais
    termoData.hasHealthIssues = checkHealthResponses();
    termoData.timestamp = new Date().toISOString();
    
    // Salvar no localStorage
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    currentUser.termo = termoData;
    currentUser.termoCompleted = true;
    currentUser.termoDate = new Date().toISOString();
    
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    console.log('📁 Dados do termo salvos:', currentUser.termo);
}

function loadSavedData() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (currentUser.termo) {
        console.log('📂 Carregando dados do termo do localStorage');
        
        Object.keys(currentUser.termo).forEach(key => {
            if (key !== 'hasHealthIssues' && key !== 'timestamp') {
                const value = currentUser.termo[key];
                const field = document.querySelector(`[name="${key}"][value="${value}"]`) || 
                             document.querySelector(`[name="${key}"]`);
                
                if (field) {
                    if (field.type === 'checkbox') {
                        field.checked = true;
                    } else if (field.type === 'radio') {
                        field.checked = true;
                    }
                }
            }
        });
    }
    
    setTimeout(() => {
        checkHealthResponses();
    }, 100);
}

function showSuccessModal() {
    const modal = document.getElementById('successModal');
    const hasHealthIssues = checkHealthResponses();
    
    if (hasHealthIssues) {
        document.getElementById('modalIcon').textContent = '⚠️';
        document.getElementById('modalTitle').textContent = 'Termo Registrado';
        document.getElementById('modalText').textContent = 'Seu termo foi registrado. Recomendamos consulta médica.';
    } else {
        document.getElementById('modalIcon').textContent = '✅';
        document.getElementById('modalTitle').textContent = 'Termo Aceito!';
        document.getElementById('modalText').textContent = 'Seu termo de responsabilidade foi registrado.';
    }
    
    document.getElementById('modalSubtext').textContent = 'Clique no botão abaixo para voltar à inscrição.';
    
    modal.style.display = 'flex';
    
    setTimeout(() => {
        modal.querySelector('.modal-content').style.transform = 'scale(1)';
        modal.querySelector('.modal-content').style.opacity = '1';
    }, 100);
}

function showFieldError(element, message) {
    clearFieldError(element);
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.color = '#dc3545';
    errorDiv.style.fontSize = '0.875rem';
    errorDiv.style.marginTop = '0.5rem';
    
    element.appendChild(errorDiv);
}

function clearFieldError(element) {
    const errorDiv = element.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

function showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
    `;
    
    if (type === 'success') {
        notification.style.background = '#27ae60';
    } else if (type === 'error') {
        notification.style.background = '#e74c3c';
    } else {
        notification.style.background = '#3498db';
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}