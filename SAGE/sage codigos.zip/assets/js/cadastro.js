// cadastro.js - VERSÃO COMPLETA E CORRIGIDA
document.addEventListener('DOMContentLoaded', function() {
    console.log('Página de cadastro carregada');
    
    const cadastroForm = document.getElementById('cadastroForm');
    const senhaInput = document.getElementById('senha');
    const confirmarSenhaInput = document.getElementById('confirmarSenha');
    const toggleSenhaBtn = document.getElementById('toggleSenha');
    const toggleConfirmarSenhaBtn = document.getElementById('toggleConfirmarSenha');
    
    // Verificar se já está logado (redirecionar se sim)
    checkIfAlreadyLoggedIn();
    
    // Configurar toggles de senha
    if (toggleSenhaBtn) {
        toggleSenhaBtn.addEventListener('click', function() {
            togglePasswordVisibility(senhaInput, toggleSenhaBtn);
        });
    }
    
    if (toggleConfirmarSenhaBtn) {
        toggleConfirmarSenhaBtn.addEventListener('click', function() {
            togglePasswordVisibility(confirmarSenhaInput, toggleConfirmarSenhaBtn);
        });
    }
    
    // Validação em tempo real
    if (senhaInput) {
        senhaInput.addEventListener('input', function() {
            validatePasswordStrength();
            validatePasswordMatch();
        });
    }
    
    if (confirmarSenhaInput) {
        confirmarSenhaInput.addEventListener('input', validatePasswordMatch);
    }
    
    // Submit do formulário
    if (cadastroForm) {
        cadastroForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Formulário de cadastro submetido');
            
            if (validateForm()) {
                registerUser();
            } else {
                showNotification('Por favor, corrija os erros no formulário', 'error');
            }
        });
    }
    
    // Validação em tempo real dos campos
    const nomeInput = document.getElementById('nome');
    const emailInput = document.getElementById('email');
    
    if (nomeInput) {
        nomeInput.addEventListener('blur', validateNome);
        nomeInput.addEventListener('input', clearFieldError);
    }
    
    if (emailInput) {
        emailInput.addEventListener('blur', validateEmail);
        emailInput.addEventListener('input', clearFieldError);
    }
    
    // Limpar erros ao digitar nos campos de senha
    if (senhaInput) {
        senhaInput.addEventListener('input', clearFieldError);
    }
    
    if (confirmarSenhaInput) {
        confirmarSenhaInput.addEventListener('input', clearFieldError);
    }
    
    // Termos de uso
    const termosInput = document.getElementById('termos');
    if (termosInput) {
        termosInput.addEventListener('change', function() {
            clearError(termosInput, document.getElementById('termosError'));
        });
    }
});

function checkIfAlreadyLoggedIn() {
    const currentSession = localStorage.getItem('currentSession');
    
    if (currentSession) {
        try {
            const session = JSON.parse(currentSession);
            const now = new Date();
            const expiresAt = new Date(session.expiresAt);
            
            if (expiresAt > now) {
                console.log('Usuário já logado - Permitindo novo cadastro');
                // OPICIONAL: Mostrar mensagem informativa
                showNotification('Você já está logado. Pode fazer novo cadastro se desejar.', 'info');
            } else {
                console.log('Sessão expirada - Limpando dados');
                localStorage.removeItem('currentUser');
                localStorage.removeItem('currentSession');
            }
        } catch (error) {
            console.error('Erro ao verificar sessão:', error);
            localStorage.removeItem('currentUser');
            localStorage.removeItem('currentSession');
        }
    }
}

function togglePasswordVisibility(passwordInput, toggleButton) {
    if (!passwordInput || !toggleButton) return;
    
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    toggleButton.textContent = type === 'password' ? '👁️' : '🔒';
}

function validateForm() {
    console.log('Validando formulário completo...');
    
    const nomeValid = validateNome();
    const emailValid = validateEmail();
    const senhaValid = validateSenha();
    const confirmarSenhaValid = validateConfirmarSenha();
    const termosValid = validateTermos();
    
    const isValid = nomeValid && emailValid && senhaValid && confirmarSenhaValid && termosValid;
    console.log('Formulário válido?', isValid);
    
    return isValid;
}

function validateNome() {
    const nomeInput = document.getElementById('nome');
    const nomeError = document.getElementById('nomeError');
    
    if (!nomeInput || !nomeError) return false;
    
    const nome = nomeInput.value.trim();
    
    if (!nome) {
        showError(nomeInput, nomeError, 'Nome completo é obrigatório');
        return false;
    }
    
    if (nome.length < 2) {
        showError(nomeInput, nomeError, 'Nome deve ter pelo menos 2 caracteres');
        return false;
    }
    
    if (nome.length > 100) {
        showError(nomeInput, nomeError, 'Nome muito longo (máximo 100 caracteres)');
        return false;
    }
    
    if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(nome)) {
        showError(nomeInput, nomeError, 'Nome deve conter apenas letras e espaços');
        return false;
    }
    
    clearError(nomeInput, nomeError);
    return true;
}

function validateEmail() {
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    
    if (!emailInput || !emailError) return false;
    
    const email = emailInput.value.trim();
    
    if (!email) {
        showError(emailInput, emailError, 'Email é obrigatório');
        return false;
    }
    
    if (!isValidEmail(email)) {
        showError(emailInput, emailError, 'Email inválido');
        return false;
    }
    
    if (emailExists(email)) {
        showError(emailInput, emailError, 'Este email já está cadastrado');
        return false;
    }
    
    clearError(emailInput, emailError);
    return true;
}

function validateSenha() {
    const senhaInput = document.getElementById('senha');
    const senhaError = document.getElementById('senhaError');
    
    if (!senhaInput || !senhaError) return false;
    
    const senha = senhaInput.value;
    
    if (!senha) {
        showError(senhaInput, senhaError, 'Senha é obrigatória');
        return false;
    }
    
    if (senha.length < 6) {
        showError(senhaInput, senhaError, 'Senha deve ter pelo menos 6 caracteres');
        return false;
    }
    
    if (senha.length > 50) {
        showError(senhaInput, senhaError, 'Senha muito longa (máximo 50 caracteres)');
        return false;
    }
    
    clearError(senhaInput, senhaError);
    return true;
}

function validateConfirmarSenha() {
    const confirmarSenhaInput = document.getElementById('confirmarSenha');
    const confirmarSenhaError = document.getElementById('confirmarSenhaError');
    const senhaInput = document.getElementById('senha');
    
    if (!confirmarSenhaInput || !confirmarSenhaError || !senhaInput) return false;
    
    const senha = senhaInput.value;
    const confirmarSenha = confirmarSenhaInput.value;
    
    if (!confirmarSenha) {
        showError(confirmarSenhaInput, confirmarSenhaError, 'Confirme sua senha');
        return false;
    }
    
    if (senha !== confirmarSenha) {
        showError(confirmarSenhaInput, confirmarSenhaError, 'Senhas não coincidem');
        return false;
    }
    
    clearError(confirmarSenhaInput, confirmarSenhaError);
    return true;
}

function validateTermos() {
    const termosInput = document.getElementById('termos');
    const termosError = document.getElementById('termosError');
    
    if (!termosInput || !termosError) return false;
    
    if (!termosInput.checked) {
        showError(termosInput, termosError, 'Você deve aceitar os termos e política de privacidade');
        return false;
    }
    
    clearError(termosInput, termosError);
    return true;
}

function validatePasswordStrength() {
    const senhaInput = document.getElementById('senha');
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    
    if (!senhaInput || !strengthBar || !strengthText) return;
    
    const senha = senhaInput.value;
    
    let strength = 0;
    let text = 'Força da senha';
    let className = '';
    
    // Critérios de força
    if (senha.length >= 6) strength++;
    if (senha.length >= 8) strength++;
    if (/[a-z]/.test(senha) && /[A-Z]/.test(senha)) strength++;
    if (/\d/.test(senha)) strength++;
    if (/[^a-zA-Z\d]/.test(senha)) strength++;
    
    // Determinar força baseada nos critérios
    if (senha.length === 0) {
        text = 'Força da senha';
        className = '';
    } else if (strength <= 2) {
        text = 'Fraca';
        className = 'weak';
    } else if (strength <= 4) {
        text = 'Média';
        className = 'medium';
    } else {
        text = 'Forte';
        className = 'strong';
    }
    
    strengthBar.className = `strength-bar ${className}`;
    strengthText.textContent = text;
}

function validatePasswordMatch() {
    const senhaInput = document.getElementById('senha');
    const confirmarSenhaInput = document.getElementById('confirmarSenha');
    const confirmarSenhaError = document.getElementById('confirmarSenhaError');
    
    if (!senhaInput || !confirmarSenhaInput || !confirmarSenhaError) return;
    
    const senha = senhaInput.value;
    const confirmarSenha = confirmarSenhaInput.value;
    
    if (confirmarSenha === '') {
        // Limpar erro se o campo estiver vazio
        clearError(confirmarSenhaInput, confirmarSenhaError);
    } else if (senha === confirmarSenha) {
        clearError(confirmarSenhaInput, confirmarSenhaError);
        // Adicionar indicação visual de sucesso
        confirmarSenhaInput.classList.add('valid');
        confirmarSenhaInput.classList.remove('invalid');
    } else {
        showError(confirmarSenhaInput, confirmarSenhaError, 'Senhas não coincidem');
    }
}

function registerUser() {
    console.log('Iniciando registro de usuário...');
    
    const userData = {
        id: 'USER_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
        nome: document.getElementById('nome').value.trim(),
        email: document.getElementById('email').value.trim().toLowerCase(),
        password: document.getElementById('senha').value,
        cpf: '000.000.000-00', // Será preenchido na tela de inscrição
        foto: null, // Será adicionado na tela de inscrição
        registrationDate: new Date().toISOString(),
        lastLogin: null,
        status: 'active'
    };
    
    console.log('Dados do usuário para registro:', { ...userData, password: '***' });
    
    // Mostrar estado de loading
    const btn = document.querySelector('.cadastro-btn');
    if (btn) {
        btn.classList.add('loading');
        btn.disabled = true;
        btn.textContent = 'CADASTRANDO...';
    }
    
    // Simular processamento do cadastro
    setTimeout(() => {
        try {
            // Salvar usuário no localStorage
            const users = JSON.parse(localStorage.getItem('users') || '[]');
            
            // Verificar duplicação final (segurança extra)
            if (emailExists(userData.email)) {
                throw new Error('Email já cadastrado');
            }
            
            users.push(userData);
            localStorage.setItem('users', JSON.stringify(users));
            
            // Criar sessão de usuário
            const sessionData = {
                userId: userData.id,
                email: userData.email,
                name: userData.nome,
                loginTime: new Date().getTime(),
                expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 horas
            };
            
            localStorage.setItem('currentUser', JSON.stringify(userData));
            localStorage.setItem('currentSession', JSON.stringify(sessionData));
            
            console.log('Usuário registrado com sucesso:', { ...userData, password: '***' });
            console.log('Total de usuários cadastrados:', users.length);
            
            // Mostrar mensagem de sucesso
            showNotification('Cadastro realizado com sucesso! Redirecionando...', 'success');
            
            // ✅ REDIRECIONAMENTO CORRETO: Cadastro vai para INSCRIÇÃO
            setTimeout(() => {
                window.location.href = '/assets/pages/inscricao.html';
            }, 1500);
            
        } catch (error) {
            console.error('Erro no registro:', error);
            
            // Restaurar botão
            if (btn) {
                btn.classList.remove('loading');
                btn.disabled = false;
                btn.textContent = 'CADASTRAR-SE E CONTINUAR';
            }
            
            showNotification('Erro ao realizar cadastro: ' + error.message, 'error');
        }
    }, 1500);
}

function emailExists(email) {
    try {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        return users.some(user => user.email.toLowerCase() === email.toLowerCase());
    } catch (error) {
        console.error('Erro ao verificar email:', error);
        return false;
    }
}

function showError(input, errorElement, message) {
    if (!input || !errorElement) return;
    
    input.classList.add('invalid');
    input.classList.remove('valid');
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    errorElement.style.color = '#e74c3c';
}

function clearError(input, errorElement) {
    if (!input || !errorElement) return;
    
    input.classList.remove('invalid');
    errorElement.textContent = '';
    errorElement.style.display = 'none';
}

function clearFieldError(e) {
    const input = e.target;
    const fieldName = input.id;
    const errorElement = document.getElementById(fieldName + 'Error');
    
    if (errorElement) {
        clearError(input, errorElement);
    }
    
    // Para campos válidos, adicionar classe valid
    if (input.value.trim() !== '') {
        input.classList.add('valid');
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showNotification(message, type = 'info') {
    // Remover notificação anterior se existir
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    if (type === 'success') {
        notification.style.background = '#27ae60';
    } else if (type === 'error') {
        notification.style.background = '#e74c3c';
    } else if (type === 'info') {
        notification.style.background = '#3498db';
    } else {
        notification.style.background = '#34495e';
    }
    
    document.body.appendChild(notification);
    
    // Auto-remover após 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}

// Adicionar estilos de animação para notificações
if (!document.getElementById('notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        @keyframes slideIn {
            from { 
                transform: translateX(100%); 
                opacity: 0; 
            }
            to { 
                transform: translateX(0); 
                opacity: 1; 
            }
        }
        
        @keyframes slideOut {
            from { 
                transform: translateX(0); 
                opacity: 1; 
            }
            to { 
                transform: translateX(100%); 
                opacity: 0; 
            }
        }
        
        .notification {
            animation: slideIn 0.3s ease;
        }
    `;
    document.head.appendChild(style);
}

// Utilitário para debug (pode ser removido em produção)
function debugUsers() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    console.log('=== DEBUG USUÁRIOS ===');
    console.log('Total:', users.length);
    users.forEach((user, index) => {
        console.log(`${index + 1}. ${user.nome} (${user.email}) - ${user.id}`);
    });
    console.log('=====================');
}

// Expor função de debug globalmente (apenas para desenvolvimento)
window.debugUsers = debugUsers;