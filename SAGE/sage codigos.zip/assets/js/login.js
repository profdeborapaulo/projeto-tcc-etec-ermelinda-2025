document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const forgotPasswordLink = document.getElementById('forgotPassword');
    
    console.log('Login page carregada');
    
    // Verificar se já está logado
    checkLoggedInUser();
    
    // Toggle de senha
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            togglePassword.textContent = type === 'password' ? '👁️' : '🔒';
        });
    }
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            
            if (validateLogin(email, password)) {
                // Criar sessão
                const userData = getUserByEmail(email);
                const sessionData = {
                    email: userData.email,
                    name: userData.nome,
                    loginTime: new Date().getTime(),
                    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
                };
                
                localStorage.setItem('currentUser', JSON.stringify(userData));
                localStorage.setItem('currentSession', JSON.stringify(sessionData));
                
                console.log('Login bem-sucedido, redirecionando...');
                showNotification('Login realizado com sucesso!', 'success');
                
                // ✅ CORREÇÃO: Redirecionar para carteirinha.html
                setTimeout(() => {
                    window.location.href = '/assets/pages/carteirinha.html';
                }, 1000);
            } else {
                console.log('Login falhou');
                showNotification('Email ou senha incorretos!', 'error');
            }
        });
    }
    
    // Esqueci minha senha
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            showPasswordRecoveryModal();
        });
    }
});

function validateLogin(email, password) {
    if (!email || !password) {
        showNotification('Preencha todos os campos', 'error');
        return false;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Email inválido', 'error');
        return false;
    }
    
    // Buscar usuário no localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    console.log('Usuários cadastrados:', users);
    
    const user = users.find(u => u.email === email);
    
    if (!user) {
        showNotification('Email não cadastrado', 'error');
        return false;
    }
    
    // Verificar senha
    if (user.password !== password) {
        showNotification('Senha incorreta', 'error');
        return false;
    }
    
    return true;
}

function getUserByEmail(email) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email) || {};
    
    // Garantir que tenha todos os campos necessários
    return {
        id: user.id || 'ID' + Date.now(),
        nome: user.nome || user.name || 'Usuário',
        email: user.email,
        cpf: user.cpf || '000.000.000-00',
        password: user.password,
        registrationDate: user.registrationDate || new Date().toISOString()
    };
}

function checkLoggedInUser() {
    const currentSession = localStorage.getItem('currentSession');
    
    if (currentSession) {
        try {
            const session = JSON.parse(currentSession);
            const now = new Date();
            const expiresAt = new Date(session.expiresAt);
            
            if (expiresAt > now) {
                console.log('Usuário já logado - Permanecendo na página de login');
                // OPICIONAL: Mostrar mensagem informativa
                showNotification('Você já está logado. Faça login novamente ou vá para a carteirinha.', 'info');
            } else {
                console.log('Sessão expirada - Limpando dados');
                localStorage.removeItem('currentUser');
                localStorage.removeItem('currentSession');
            }
        } catch (error) {
            console.error('Erro ao verificar sessão:', error);
            localStorage.removeItem('currentUser');
            localStorage.removeItem('currentSession');
        }
    }
}

function showPasswordRecoveryModal() {
    const modalHTML = `
        <div class="modal-overlay" id="passwordRecoveryModal">
            <div class="modal-content">
                <h3>Recuperar Senha</h3>
                <p>Digite seu email para receber as instruções de recuperação:</p>
                <input type="email" id="recoveryEmail" placeholder="seu@email.com">
                <div class="modal-buttons">
                    <button id="sendRecovery" class="btn-primary">Enviar Instruções</button>
                    <button id="cancelRecovery" class="btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const modal = document.getElementById('passwordRecoveryModal');
    const sendBtn = document.getElementById('sendRecovery');
    const cancelBtn = document.getElementById('cancelRecovery');
    const recoveryEmail = document.getElementById('recoveryEmail');
    
    // Adicionar estilos CSS para o modal
    addModalStyles();
    
    // Focar no input do email
    setTimeout(() => {
        if (recoveryEmail) recoveryEmail.focus();
    }, 100);
    
    if (sendBtn) {
        sendBtn.addEventListener('click', function() {
            const email = recoveryEmail.value.trim();
            if (email && isValidEmail(email)) {
                initiatePasswordRecovery(email);
                if (modal) modal.remove();
            } else {
                showNotification('Por favor, insira um email válido.', 'error');
                if (recoveryEmail) recoveryEmail.focus();
            }
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            if (modal) modal.remove();
        });
    }
    
    // Fechar modal ao clicar fora
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    // Fechar com ESC
    function closeModal(e) {
        if (e.key === 'Escape' && modal) {
            modal.remove();
            document.removeEventListener('keydown', closeModal);
        }
    }
    document.addEventListener('keydown', closeModal);
}

function addModalStyles() {
    if (document.getElementById('modal-styles')) return;
    
    const styles = `
        <style id="modal-styles">
            .modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.6);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 1000;
            }
            
            .modal-content {
                background: white;
                padding: 2rem;
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                width: 90%;
                max-width: 400px;
                text-align: center;
            }
            
            .modal-content h3 {
                color: hsl(220, 73%, 20%);
                margin-bottom: 1rem;
                font-size: 1.4rem;
            }
            
            .modal-content p {
                color: #5a6c7d;
                margin-bottom: 1.5rem;
                line-height: 1.4;
            }
            
            .modal-content input {
                width: 100%;
                padding: 12px 16px;
                border: 2px solid #e8ecef;
                border-radius: 8px;
                font-size: 1rem;
                margin-bottom: 1.5rem;
                background-color: #f8f9fa;
            }
            
            .modal-content input:focus {
                outline: none;
                border-color: hsl(220, 73%, 20%);
                background-color: white;
            }
            
            .modal-buttons {
                display: flex;
                gap: 10px;
                justify-content: center;
            }
            
            .btn-primary {
                background: #e3a627;
                color: white;
                border: none;
                padding: 12px 20px;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                flex: 1;
            }
            
            .btn-primary:hover {
                background: #d1941f;
            }
            
            .btn-secondary {
                background: #6c757d;
                color: white;
                border: none;
                padding: 12px 20px;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                flex: 1;
            }
            
            .btn-secondary:hover {
                background: #5a6268;
            }
        </style>
    `;
    
    document.head.insertAdjacentHTML('beforeend', styles);
}

function initiatePasswordRecovery(email) {
    // Verificar se o email existe no sistema
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userExists = users.some(u => u.email === email);
    
    if (!userExists) {
        showNotification('Email não encontrado em nosso sistema.', 'error');
        return;
    }
    
    // Simular envio de email
    const recoveryToken = generateRecoveryToken();
    
    // Salvar token temporário
    const recoveryData = {
        email: email,
        token: recoveryToken,
        expires: new Date().getTime() + (60 * 60 * 1000) // 1 hora
    };
    
    localStorage.setItem('passwordRecovery', JSON.stringify(recoveryData));
    
    // Simular envio
    console.log(`Email de recuperação enviado para: ${email}`);
    console.log(`Token de recuperação: ${recoveryToken}`);
    
    showNotification('Instruções de recuperação enviadas para seu email!', 'success');
}

function generateRecoveryToken() {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showNotification(message, type = 'info') {
    // Remover notificação anterior se existir
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    if (type === 'success') {
        notification.style.background = '#27ae60';
    } else if (type === 'error') {
        notification.style.background = '#e74c3c';
    } else {
        notification.style.background = '#3498db';
    }
    
    document.body.appendChild(notification);
    
    // Auto-remover após 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Adicionar estilos de animação para a notificação
if (!document.getElementById('notification-styles')) {
    const notificationStyles = document.createElement('style');
    notificationStyles.id = 'notification-styles';
    notificationStyles.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        .notification {
            animation: slideIn 0.3s ease;
        }
        
        .notification.hiding {
            animation: slideOut 0.3s ease forwards;
        }
    `;
    document.head.appendChild(notificationStyles);
}