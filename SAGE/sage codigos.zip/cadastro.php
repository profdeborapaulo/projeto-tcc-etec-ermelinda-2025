<?php
session_start();
require_once 'config/conexao.php';

$msg_erro = "";
$msg_sucesso = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $email = $conexao->real_escape_string($_POST['email']);
    $senha = $_POST['senha'];
    $confirma_senha = $_POST['confirmarSenha'];

    // Validações básicas
    if ($senha !== $confirma_senha) {
        $msg_erro = "As senhas não coincidem!";
    } else {
        // Verifica se email já existe
        $sql_check = "SELECT id FROM usuarios WHERE email = '$email'";
        $result = $conexao->query($sql_check);

        if ($result->num_rows > 0) {
            $msg_erro = "Este email já está cadastrado.";
        } else {
            // Insere no banco (Senha sem hash para facilitar seu TCC, mas ideal é usar password_hash)
            $sql_insert = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
            
            if ($conexao->query($sql_insert) === TRUE) {
                $msg_sucesso = "Cadastro realizado com sucesso! Redirecionando...";
                header("refresh:2;url=login.php");
            } else {
                $msg_erro = "Erro ao cadastrar: " . $conexao->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAGE - Cadastro</title>
    <link rel="icon" href="assets/img/Logo.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/cadastro.css">
    <style>
        /* CSS Extra para mensagens PHP */
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 8px; text-align: center; font-weight: bold; }
        .alert-danger { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    </style>
</head>
<body>
    <div class="cadastro-container">
        <div class="cadastro-header">
            <h1>Conheça o SAGE!</h1>
            <p class="system-description">O SAGE é um Sistema Automatizado de Gestão Esportiva</p>
            <div class="divider"></div>
        </div>

        <h2 class="form-title">Crie o seu cadastro</h2>

        <?php if(!empty($msg_erro)): ?>
            <div class="alert alert-danger"><?php echo $msg_erro; ?></div>
        <?php endif; ?>
        <?php if(!empty($msg_sucesso)): ?>
            <div class="alert alert-success"><?php echo $msg_sucesso; ?></div>
        <?php endif; ?>

        <form class="cadastro-form" id="cadastroForm" action="cadastro.php" method="POST">
            <div class="form-group">
                <label for="nome">Nome completo</label>
                <input type="text" id="nome" name="nome" class="form-control" placeholder="Seu nome completo" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="seu@email.com" required>
            </div>
            
            <div class="form-group password-group">
                <label for="senha">Senha</label>
                <div class="password-input-container">
                    <input type="password" id="senha" name="senha" class="form-control" placeholder="Crie uma senha" required>
                </div>
            </div>

            <div class="form-group">
                <label for="confirmarSenha">Confirmar senha</label>
                <div class="password-input-container">
                    <input type="password" id="confirmarSenha" name="confirmarSenha" class="form-control" placeholder="Digite a senha novamente" required>
                </div>
            </div>

            <button type="submit" class="cadastro-btn">CADASTRAR-SE E CONTINUAR</button>
        </form>

        <div class="cadastro-footer">
            <p>Já tem uma conta? <a href="login.php" class="link">Faça login</a></p>
        </div>
    </div>
    </body>
</html>