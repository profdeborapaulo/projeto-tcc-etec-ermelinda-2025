<?php
session_start();
require_once 'config/conexao.php';

// --- 1. SEGURANÇA ---
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$id = $_SESSION['user_id'];
$admin_check = $conexao->query("SELECT is_admin, nome FROM usuarios WHERE id = '$id'")->fetch_assoc();

if ($admin_check['is_admin'] != 1) { header("Location: index.php"); exit; }

$admin_nome = $admin_check['nome'];

// --- 2. LÓGICA PHP (BACKEND) ---

// Ação: EDITAR ALUNO E ANEXAR PRONTUÁRIO (NOVO)
if (isset($_POST['edit_aluno'])) {
    $id_aluno = intval($_POST['id_aluno']);
    
    // Sanitização
    $nome = $conexao->real_escape_string($_POST['nome']);
    $cpf = $conexao->real_escape_string($_POST['cpf']);
    $telefone = $conexao->real_escape_string($_POST['telefone']);
    $modalidade = $conexao->real_escape_string($_POST['modalidade']);
    $horario = $conexao->real_escape_string($_POST['horario']);
    $status = $conexao->real_escape_string($_POST['status']);
    
    // Lógica de Upload do Prontuário
    $sql_extra = ""; // Para adicionar ao UPDATE apenas se houver arquivo
    
    if (isset($_FILES['novo_prontuario']) && $_FILES['novo_prontuario']['error'] == 0) {
        $dir = 'assets/docs/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        
        $ext = pathinfo($_FILES['novo_prontuario']['name'], PATHINFO_EXTENSION);
        // Aceita PDF e Imagens
        if (in_array(strtolower($ext), ['pdf', 'jpg', 'jpeg', 'png'])) {
            $novo_nome = "prontuario_" . $id_aluno . "_" . time() . "." . $ext;
            if (move_uploaded_file($_FILES['novo_prontuario']['tmp_name'], $dir . $novo_nome)) {
                $caminho = $dir . $novo_nome;
                $sql_extra = ", prontuario_caminho = '$caminho'";
            }
        }
    }
    
    // Atualiza dados
    $sql_update = "UPDATE insc  ricoes SET 
                   nome_completo = '$nome', 
                   cpf = '$cpf', 
                   telefone = '$telefone', 
                   modalidade = '$modalidade', 
                   horario = '$horario',
                   status_inscricao = '$status' 
                   $sql_extra
                   WHERE id = '$id_aluno'";
                   
    if($conexao->query($sql_update)) {
        // Se mudou para ativo, atualiza vagas (lógica simplificada)
        if($status == 'ativo') {
             $conexao->query("UPDATE esportes SET vagas_ocupadas = vagas_ocupadas + 1 WHERE nome = '$modalidade'");
        }
        header("Location: admin.php?msg=aluno_editado");
    } else {
        header("Location: admin.php?msg=erro");
    }
    exit;
}

// Ação: QR CODE SCAN
if (isset($_GET['qr_scan'])) {
    $id_aluno = intval($_GET['qr_scan']);
    $data = date('Y-m-d');
    $existe = $conexao->query("SELECT id, nome_completo FROM inscricoes WHERE id = '$id_aluno' AND status_inscricao = 'ativo'");
    
    if ($existe->num_rows > 0) {
        $aluno = $existe->fetch_assoc();
        $check = $conexao->query("SELECT id FROM frequencia WHERE aluno_id = '$id_aluno' AND data_aula = '$data'");
        
        if ($check->num_rows == 0) {
            $conexao->query("INSERT INTO frequencia (aluno_id, data_aula, presenca) VALUES ('$id_aluno', '$data', 'presente')");
            $msg_type = "success"; $msg_text = "Presença confirmada: " . $aluno['nome_completo'];
        } else {
            $msg_type = "info"; $msg_text = "Aluno já presente hoje.";
        }
    } else {
        $msg_type = "error"; $msg_text = "Aluno não encontrado ou inativo.";
    }
    header("Location: admin.php?msg_qr=$msg_type&text_qr=" . urlencode($msg_text));
    exit;
}

// Ação: Lançar Frequência Manual
if (isset($_GET['presenca']) && isset($_GET['id'])) {
    $id_aluno = intval($_GET['id']);
    $tipo = $_GET['presenca']; 
    $data = date('Y-m-d');
    $check = $conexao->query("SELECT id FROM frequencia WHERE aluno_id = '$id_aluno' AND data_aula = '$data'");
    
    if($check->num_rows == 0){
        $conexao->query("INSERT INTO frequencia (aluno_id, data_aula, presenca) VALUES ('$id_aluno', '$data', '$tipo')");
        header("Location: admin.php?msg=presenca_sucesso");
    } else {
        $conexao->query("UPDATE frequencia SET presenca = '$tipo' WHERE aluno_id = '$id_aluno' AND data_aula = '$data'");
        header("Location: admin.php?msg=presenca_atualizada");
    }
    exit;
}

// Ação: Aprovar/Rejeitar
if (isset($_GET['acao']) && isset($_GET['id'])) {
    $id_aluno = intval($_GET['id']);
    $status = ($_GET['acao'] == 'aprovar') ? 'ativo' : 'rejeitado';
    $conexao->query("UPDATE inscricoes SET status_inscricao = '$status' WHERE id = '$id_aluno'");
    
    if($status == 'ativo'){
        $mod = $conexao->query("SELECT modalidade FROM inscricoes WHERE id = '$id_aluno'")->fetch_assoc()['modalidade'];
        $conexao->query("UPDATE esportes SET vagas_ocupadas = vagas_ocupadas + 1 WHERE nome = '$mod'");
    }
    header("Location: admin.php?msg=status_atualizado"); exit;
}

// Ações de Esporte
if (isset($_POST['add_esporte'])) {
    $nome = $conexao->real_escape_string($_POST['nome_esporte']);
    $vagas = intval($_POST['vagas']);
    $conexao->query("INSERT INTO esportes (nome, vagas_totais) VALUES ('$nome', '$vagas')");
    header("Location: admin.php?msg=esporte_criado"); exit;
}
if (isset($_POST['edit_esporte'])) {
    $id_esp = intval($_POST['id_esporte']);
    $nome = $conexao->real_escape_string($_POST['nome_esporte']);
    $vagas = intval($_POST['vagas']);
    $conexao->query("UPDATE esportes SET nome = '$nome', vagas_totais = '$vagas' WHERE id = '$id_esp'");
    header("Location: admin.php?msg=esporte_editado"); exit;
}

// --- 3. CONSULTAS ---
$total_ativos = $conexao->query("SELECT COUNT(*) as c FROM inscricoes WHERE status_inscricao = 'ativo'")->fetch_assoc()['c'];
$total_pendentes = $conexao->query("SELECT COUNT(*) as c FROM inscricoes WHERE status_inscricao = 'pendente'")->fetch_assoc()['c'];
$total_esportes = $conexao->query("SELECT COUNT(*) as c FROM esportes")->fetch_assoc()['c'];
$presenca_hoje = $conexao->query("SELECT COUNT(*) as c FROM frequencia WHERE data_aula = CURDATE() AND presenca = 'presente'")->fetch_assoc()['c'];

$pendentes_list = $conexao->query("SELECT * FROM inscricoes WHERE status_inscricao = 'pendente' ORDER BY id DESC");
$ativos_list = $conexao->query("SELECT * FROM inscricoes WHERE status_inscricao = 'ativo' ORDER BY nome_completo ASC");
$esportes_list = $conexao->query("SELECT * FROM esportes");

// Lista de modalidades para o select do modal
$modalidades_opt = $conexao->query("SELECT nome FROM esportes");
$lista_mods = [];
while($m = $modalidades_opt->fetch_assoc()) { $lista_mods[] = $m['nome']; }

// Gráfico
$grafico_sql = $conexao->query("SELECT modalidade, COUNT(*) as total FROM inscricoes WHERE status_inscricao = 'ativo' GROUP BY modalidade");
$labels = []; $data_chart = [];
while($row = $grafico_sql->fetch_assoc()) {
    $labels[] = $row['modalidade'];
    $data_chart[] = $row['total'];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - SAGE</title>
    <link rel="icon" href="assets/img/Logo.png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>

    <script>
        tailwind.config = { theme: { extend: { colors: { sage: { dark: '#020D30', blue: '#1e3a8a', gold: '#e3a627' } } } } }
    </script>
    <style>.sidebar-transition { transition: transform 0.3s ease-in-out; }</style>
</head>
<body class="bg-slate-100 font-sans text-slate-800 h-screen flex overflow-hidden">

    <div id="mobile-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-black/50 z-20 hidden md:hidden glass-effect"></div>

    <aside id="sidebar" class="fixed inset-y-0 left-0 z-30 w-64 bg-sage-dark text-white flex flex-col shadow-2xl transform -translate-x-full md:translate-x-0 md:static sidebar-transition">
        <div class="p-6 flex items-center justify-between border-b border-white/10">
            <div class="flex items-center">
                <img src="assets/img/Logo.png" class="h-10 w-auto mr-3">
                <span class="font-bold text-xl tracking-wider">SAGE<span class="text-sage-gold">ADMIN</span></span>
            </div>
            <button onclick="toggleSidebar()" class="md:hidden text-white text-xl"><i class="fas fa-times"></i></button>
        </div>

        <nav class="flex-1 py-6 overflow-y-auto">
            <ul class="space-y-2 px-4">
                <li><button onclick="openTab('dashboard')" class="nav-item w-full flex items-center p-3 rounded-xl bg-sage-gold text-sage-dark font-bold shadow-lg transition-all"><i class="fas fa-chart-pie w-6"></i> <span class="ml-3">Visão Geral</span></button></li>
                <li><button onclick="openTab('pendentes')" class="nav-item w-full flex items-center p-3 rounded-xl hover:bg-white/10 text-slate-300 hover:text-white transition-all"><i class="fas fa-user-clock w-6"></i> <span class="ml-3">Aprovações</span><?php if($total_pendentes > 0): ?><span class="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full font-bold"><?php echo $total_pendentes; ?></span><?php endif; ?></button></li>
                <li><button onclick="openTab('frequencia')" class="nav-item w-full flex items-center p-3 rounded-xl hover:bg-white/10 text-slate-300 hover:text-white transition-all"><i class="fas fa-calendar-check w-6"></i> <span class="ml-3">Frequência</span></button></li>
                <li><button onclick="openTab('esportes')" class="nav-item w-full flex items-center p-3 rounded-xl hover:bg-white/10 text-slate-300 hover:text-white transition-all"><i class="fas fa-dumbbell w-6"></i> <span class="ml-3">Esportes</span></button></li>
            </ul>
        </nav>

        <div class="p-4 border-t border-white/10">
            <a href="logout.php" class="flex items-center justify-center w-full p-3 rounded-xl border border-red-500/50 text-red-400 hover:bg-red-500 hover:text-white transition"><i class="fas fa-sign-out-alt mr-2"></i> Sair</a>
        </div>
    </aside>

    <main class="flex-1 flex flex-col h-screen overflow-hidden relative">
        <header class="h-16 bg-white shadow-sm flex items-center justify-between px-4 z-10">
            <div class="flex items-center gap-4">
                <button onclick="toggleSidebar()" class="md:hidden text-sage-dark text-2xl p-2"><i class="fas fa-bars"></i></button>
                <h2 class="text-xl font-bold text-sage-dark truncate" id="page-title">Dashboard</h2>
            </div>
            <div class="flex items-center gap-3">
                <button onclick="abrirScanner()" class="hidden md:flex bg-sage-dark text-white px-4 py-2 rounded-lg items-center gap-2 hover:bg-blue-900 transition shadow-md"><i class="fas fa-qrcode"></i> <span>Escanear</span></button>
                <div class="text-right hidden sm:block"><p class="text-sm font-bold text-sage-dark"><?php echo $admin_nome; ?></p><p class="text-xs text-slate-500">Admin</p></div>
                <div class="h-10 w-10 rounded-full bg-sage-gold flex items-center justify-center text-white font-bold shadow"><?php echo substr($admin_nome, 0, 1); ?></div>
            </div>
        </header>

        <div class="flex-1 overflow-y-auto p-4 md:p-6 scroll-smooth bg-slate-100">
            
            <div id="tab-dashboard" class="tab-content">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <div class="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-sage-gold flex justify-between items-center"><div><p class="text-slate-500 text-sm font-bold">Presença Hoje</p><h3 class="text-4xl font-bold text-sage-gold"><?php echo $presenca_hoje; ?></h3></div><div class="h-14 w-14 bg-yellow-100 text-sage-gold rounded-full flex items-center justify-center text-2xl"><i class="fas fa-check-double"></i></div></div>
                    <div class="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-green-500 flex justify-between items-center"><div><p class="text-slate-500 text-sm font-bold">Ativos</p><h3 class="text-3xl font-bold text-sage-dark"><?php echo $total_ativos; ?></h3></div><div class="h-12 w-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-xl"><i class="fas fa-users"></i></div></div>
                    <div class="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-red-500 flex justify-between items-center"><div><p class="text-slate-500 text-sm font-bold">Pendentes</p><h3 class="text-3xl font-bold text-red-500"><?php echo $total_pendentes; ?></h3></div><div class="h-12 w-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center text-xl"><i class="fas fa-clock"></i></div></div>
                    <div class="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-blue-500 flex justify-between items-center"><div><p class="text-slate-500 text-sm font-bold">Modalidades</p><h3 class="text-3xl font-bold text-blue-600"><?php echo $total_esportes; ?></h3></div><div class="h-12 w-12 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center text-xl"><i class="fas fa-running"></i></div></div>
                </div>
                <div class="bg-white p-6 rounded-2xl shadow-sm mb-20 md:mb-8"><h3 class="text-lg font-bold text-sage-dark mb-4">Alunos por Modalidade</h3><div class="h-64 w-full"><canvas id="chartModalidades"></canvas></div></div>
            </div>

            <div id="tab-pendentes" class="tab-content hidden">
                <div class="bg-white rounded-2xl shadow-sm overflow-hidden mb-20">
                    <div class="p-6 border-b"><h3 class="text-lg font-bold text-sage-dark">Solicitações de Cadastro</h3></div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 text-slate-500 text-xs uppercase font-bold"><tr><th class="p-4">Aluno</th><th class="p-4 hidden md:table-cell">Documento</th><th class="p-4 text-center">Ação</th></tr></thead>
                            <tbody class="divide-y">
                                <?php while($p = $pendentes_list->fetch_assoc()): ?>
                                <tr class="hover:bg-slate-50">
                                    <td class="p-4">
                                        <p class="font-bold text-sage-dark"><?php echo $p['nome_completo']; ?></p>
                                        <p class="text-xs text-blue-600 font-bold bg-blue-100 inline-block px-2 py-0.5 rounded mt-1"><?php echo $p['modalidade']; ?></p>
                                    </td>
                                    <td class="p-4 hidden md:table-cell">
                                        <?php if($p['atestado_medico']): ?>
                                            <a href="<?php echo $p['atestado_medico']; ?>" target="_blank" class="text-sage-gold font-bold flex items-center gap-2 hover:underline"><i class="fas fa-file-pdf"></i> Ver Atestado</a>
                                        <?php else: ?>
                                            <span class="text-red-400 text-xs font-bold">Pendente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 flex justify-center gap-2">
                                        <button onclick='abrirModalEdicaoAluno(<?php echo json_encode($p); ?>)' class="bg-blue-500 text-white p-2 rounded-lg shadow hover:bg-blue-600" title="Editar Dados"><i class="fas fa-edit"></i></button>
                                        
                                        <button onclick="confirmarAcao('aprovar', <?php echo $p['id']; ?>)" class="bg-green-500 text-white p-2 rounded-lg shadow hover:bg-green-600"><i class="fas fa-check"></i></button>
                                        <button onclick="confirmarAcao('rejeitar', <?php echo $p['id']; ?>)" class="bg-red-500 text-white p-2 rounded-lg shadow hover:bg-red-600"><i class="fas fa-times"></i></button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php if($pendentes_list->num_rows == 0) echo "<tr><td colspan='3' class='p-6 text-center text-slate-400'>Nada pendente.</td></tr>"; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="tab-frequencia" class="tab-content hidden">
                <div class="bg-white p-3 rounded-xl shadow-sm mb-4 flex items-center gap-3 sticky top-0 z-10">
                    <i class="fas fa-search text-slate-400 ml-2"></i>
                    <input type="text" id="searchAluno" onkeyup="filtrarAlunos()" placeholder="Buscar aluno..." class="w-full outline-none">
                </div>
                <div class="bg-white rounded-2xl shadow-sm overflow-hidden mb-20">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 text-slate-500 text-xs uppercase font-bold"><tr><th class="p-4">Aluno</th><th class="p-4 text-center">Ações / Presença</th></tr></thead>
                            <tbody class="divide-y">
                                <?php while($a = $ativos_list->fetch_assoc()): 
                                    $fid = $a['id']; $hoje = date('Y-m-d');
                                    $status_dia = $conexao->query("SELECT presenca FROM frequencia WHERE aluno_id='$fid' AND data_aula='$hoje'")->fetch_assoc();
                                ?>
                                <tr class="hover:bg-slate-50 aluno-row">
                                    <td class="p-4">
                                        <p class="font-bold text-sage-dark nome-aluno"><?php echo $a['nome_completo']; ?></p>
                                        <p class="text-xs text-slate-500"><?php echo $a['modalidade']; ?> • <?php echo $a['horario']; ?></p>
                                    </td>
                                    <td class="p-4 flex justify-center gap-1 flex-wrap items-center">
                                        <button onclick='abrirModalEdicaoAluno(<?php echo json_encode($a); ?>)' class="bg-blue-100 text-blue-600 p-2 rounded-lg mr-2 hover:bg-blue-200" title="Editar Aluno"><i class="fas fa-edit"></i></button>
                                        
                                        <a href="admin.php?presenca=presente&id=<?php echo $a['id']; ?>" class="<?php echo ($status_dia['presenca']??'')=='presente' ? 'bg-green-500 text-white' : 'bg-white text-green-600 border border-green-200'; ?> px-3 py-1 rounded text-xs font-bold">P</a>
                                        <a href="admin.php?presenca=falta&id=<?php echo $a['id']; ?>" class="<?php echo ($status_dia['presenca']??'')=='falta' ? 'bg-red-500 text-white' : 'bg-white text-red-600 border border-red-200'; ?> px-3 py-1 rounded text-xs font-bold">F</a>
                                        <a href="admin.php?presenca=justificada&id=<?php echo $a['id']; ?>" class="<?php echo ($status_dia['presenca']??'')=='justificada' ? 'bg-yellow-500 text-white' : 'bg-white text-yellow-600 border border-yellow-200'; ?> px-3 py-1 rounded text-xs font-bold">J</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="tab-esportes" class="tab-content hidden">
                <div class="bg-white p-6 rounded-xl shadow-md mb-6">
                    <h3 class="font-bold mb-3">Adicionar Modalidade</h3>
                    <form method="POST" class="flex flex-col sm:flex-row gap-3">
                        <input type="text" name="nome_esporte" placeholder="Nome" class="border rounded-lg p-2 flex-1" required>
                        <input type="number" name="vagas" placeholder="Vagas" class="border rounded-lg p-2 w-full sm:w-24" required>
                        <button type="submit" name="add_esporte" class="bg-sage-dark text-white px-4 py-2 rounded-lg font-bold">Add</button>
                    </form>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-20">
                    <?php while($esp = $esportes_list->fetch_assoc()): $pc = ($esp['vagas_ocupadas'] / $esp['vagas_totais']) * 100; ?>
                    <div class="bg-white p-5 rounded-xl shadow-sm border relative">
                        <div class="flex justify-between"><h4 class="font-bold text-sage-dark"><?php echo $esp['nome']; ?></h4><button onclick="editarEsporte(<?php echo $esp['id']; ?>, '<?php echo $esp['nome']; ?>', <?php echo $esp['vagas_totais']; ?>)" class="text-slate-400 hover:text-sage-gold"><i class="fas fa-edit"></i></button></div>
                        <p class="text-sm text-slate-500 mt-1"><?php echo $esp['vagas_ocupadas']; ?> / <?php echo $esp['vagas_totais']; ?> Vagas</p>
                        <div class="w-full bg-slate-100 h-2 rounded-full mt-3"><div class="bg-sage-gold h-2 rounded-full" style="width: <?php echo $pc; ?>%"></div></div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
        <button onclick="abrirScanner()" class="md:hidden fixed bottom-6 right-6 bg-sage-gold text-sage-dark p-4 rounded-full shadow-2xl z-50 hover:scale-110 transition-transform flex items-center justify-center"><i class="fas fa-qrcode text-2xl"></i></button>
    </main>

    <div id="editAlunoModal" class="fixed inset-0 bg-black/60 hidden flex items-center justify-center z-50 px-4 backdrop-blur-sm overflow-y-auto">
        <div class="bg-white p-6 rounded-2xl w-full max-w-lg shadow-2xl my-8">
            <div class="flex justify-between items-center mb-4 border-b pb-2">
                <h3 class="text-xl font-bold text-sage-dark">Editar Aluno</h3>
                <button onclick="document.getElementById('editAlunoModal').classList.add('hidden')" class="text-slate-400 hover:text-red-500 text-2xl">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_aluno" value="1">
                <input type="hidden" name="id_aluno" id="ea_id">
                
                <div class="grid grid-cols-1 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Completo</label>
                        <input type="text" name="nome" id="ea_nome" class="w-full border rounded p-2 focus:border-sage-gold outline-none">
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">CPF</label>
                        <input type="text" name="cpf" id="ea_cpf" class="w-full border rounded p-2 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label>
                        <input type="text" name="telefone" id="ea_telefone" class="w-full border rounded p-2 outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Modalidade</label>
                        <select name="modalidade" id="ea_modalidade" class="w-full border rounded p-2 bg-white">
                            <?php foreach($lista_mods as $m): ?>
                                <option value="<?php echo $m; ?>"><?php echo $m; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Horário</label>
                        <select name="horario" id="ea_horario" class="w-full border rounded p-2 bg-white">
                            <option value="Manhã">Manhã</option><option value="Tarde">Tarde</option><option value="Noite">Noite</option>
                        </select>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Status da Inscrição</label>
                    <select name="status" id="ea_status" class="w-full border rounded p-2 bg-white font-bold">
                        <option value="ativo" class="text-green-600">ATIVO</option>
                        <option value="pendente" class="text-yellow-600">PENDENTE</option>
                        <option value="rejeitado" class="text-red-600">REJEITADO</option>
                    </select>
                </div>
                
                <div class="mb-6 p-4 bg-slate-50 rounded-lg border border-dashed border-slate-300">
                    <label class="block text-xs font-bold text-sage-dark uppercase mb-2"><i class="fas fa-folder-plus"></i> Anexar Nova Ficha / Prontuário</label>
                    <input type="file" name="novo_prontuario" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-sage-gold file:text-sage-dark hover:file:bg-yellow-400">
                    <p class="text-xs text-slate-400 mt-1">Substitui arquivos anteriores (PDF/Imagem).</p>
                </div>
                
                <div class="flex justify-end">
                    <button type="submit" class="w-full bg-sage-gold text-sage-dark font-bold py-3 rounded-lg hover:bg-yellow-400 transition shadow-md">Salvar Alterações</button>
                </div>
            </form>
        </div>
    </div>

    <div id="scannerModal" class="fixed inset-0 bg-black/90 z-50 hidden flex flex-col items-center justify-center">
        <div class="relative w-full max-w-md px-4">
            <div class="bg-white rounded-2xl overflow-hidden shadow-2xl">
                <div class="p-4 bg-sage-dark text-white flex justify-between items-center">
                    <h3 class="font-bold">Escanear Carteirinha</h3>
                    <button onclick="fecharScanner()" class="text-2xl">&times;</button>
                </div>
                <div class="p-4"><div id="reader" class="w-full bg-black"></div></div>
            </div>
        </div>
    </div>

    <div id="editModal" class="fixed inset-0 bg-black/60 hidden flex items-center justify-center z-50 px-4">
        <div class="bg-white p-6 rounded-2xl w-full max-w-sm shadow-2xl">
            <h3 class="text-xl font-bold text-sage-dark mb-4">Editar Modalidade</h3>
            <form method="POST">
                <input type="hidden" name="edit_esporte" value="1">
                <input type="hidden" name="id_esporte" id="modal_id">
                <input type="text" name="nome_esporte" id="modal_nome" class="w-full border rounded p-2 mb-3">
                <input type="number" name="vagas" id="modal_vagas" class="w-full border rounded p-2 mb-4">
                <button type="submit" class="bg-sage-gold w-full py-2 rounded font-bold">Salvar</button>
            </form>
        </div>
    </div>

    <script>
        function toggleSidebar() { document.getElementById('sidebar').classList.toggle('-translate-x-full'); document.getElementById('mobile-overlay').classList.toggle('hidden'); }
        function openTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            document.getElementById('tab-' + tabName).classList.remove('hidden');
            if(window.innerWidth < 768) toggleSidebar();
            document.querySelectorAll('.nav-item').forEach(el => { el.classList.remove('bg-sage-gold', 'text-sage-dark', 'shadow-lg'); el.classList.add('text-slate-300', 'hover:bg-white/10'); });
            event.currentTarget.classList.remove('text-slate-300'); event.currentTarget.classList.add('bg-sage-gold', 'text-sage-dark', 'shadow-lg');
        }

        // Função para abrir o modal de edição de aluno e preencher os dados
        function abrirModalEdicaoAluno(dados) {
            document.getElementById('ea_id').value = dados.id;
            document.getElementById('ea_nome').value = dados.nome_completo;
            document.getElementById('ea_cpf').value = dados.cpf;
            document.getElementById('ea_telefone').value = dados.telefone;
            document.getElementById('ea_modalidade').value = dados.modalidade;
            document.getElementById('ea_horario').value = dados.horario;
            document.getElementById('ea_status').value = dados.status_inscricao;
            document.getElementById('editAlunoModal').classList.remove('hidden');
        }

        // Scanner
        let html5QrcodeScanner;
        function abrirScanner() {
            document.getElementById('scannerModal').classList.remove('hidden');
            html5QrcodeScanner = new Html5Qrcode("reader");
            html5QrcodeScanner.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } },
                (decodedText) => { html5QrcodeScanner.stop().then(() => { window.location.href = `admin.php?qr_scan=${decodedText}`; }); }
            ).catch(err => Swal.fire('Erro', 'Câmera não acessível.', 'error'));
        }
        function fecharScanner() { if(html5QrcodeScanner) html5QrcodeScanner.stop(); document.getElementById('scannerModal').classList.add('hidden'); }

        // Utilitários
        function confirmarAcao(acao, id) { Swal.fire({ title: 'Confirmar?', showCancelButton: true, confirmButtonText: 'Sim' }).then((res) => { if(res.isConfirmed) window.location.href = `admin.php?acao=${acao}&id=${id}`; }); }
        function editarEsporte(id, nome, vagas) { document.getElementById('modal_id').value = id; document.getElementById('modal_nome').value = nome; document.getElementById('modal_vagas').value = vagas; document.getElementById('editModal').classList.remove('hidden'); }
        function filtrarAlunos() { let input = document.getElementById('searchAluno').value.toUpperCase(); document.querySelectorAll('.aluno-row').forEach(row => { row.style.display = row.innerText.toUpperCase().includes(input) ? '' : 'none'; }); }
        
        // Charts & Mensagens
        const ctx = document.getElementById('chartModalidades');
        if (ctx) { new Chart(ctx, { type: 'doughnut', data: { labels: <?php echo json_encode($labels); ?>, datasets: [{ data: <?php echo json_encode($data_chart); ?>, backgroundColor: ['#1e3a8a', '#e3a627', '#10b981', '#ef4444'], borderWidth: 0 }] }, options: { responsive: true, maintainAspectRatio: false } }); }
        
        const urlParams = new URLSearchParams(window.location.search);
        if(urlParams.has('msg_qr')) {
            const type = urlParams.get('msg_qr');
            Swal.fire({ icon: type, title: type=='success'?'Presença Confirmada!':'Atenção', text: urlParams.get('text_qr'), timer: 3000, showConfirmButton: false });
        } else if (urlParams.has('msg')) {
            Swal.fire({ icon: 'success', title: 'Sucesso', timer: 1500, showConfirmButton: false });
        }
        openTab('dashboard');
    </script>
</body>
</html>