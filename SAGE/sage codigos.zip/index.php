<?php
// index.php
session_start();
require_once 'config/conexao.php';

// Se não estiver logado, manda para o login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// 1. Verifica se é ADMIN
$sql = "SELECT is_admin FROM usuarios WHERE id = '$user_id'";
$res = $conexao->query($sql);
$user = $res->fetch_assoc();

if ($user['is_admin'] == 1) {
    header("Location: admin.php");
    exit;
}

// 2. Verifica se já tem INSCRIÇÃO feita
$sql_inscricao = "SELECT id FROM inscricoes WHERE usuario_id = '$user_id' ORDER BY id DESC LIMIT 1";
$res_inscricao = $conexao->query($sql_inscricao);

if ($res_inscricao->num_rows > 0) {
    // Já tem inscrição -> Vai direto para a Carteirinha
    header("Location: carteirinha.php");
    exit;
} else {
    // Não tem inscrição -> Vai para o formulário
    header("Location: inscricao.php");
    exit;
}
?>